# How to use PRISM

PRISM is a pick-and-place cell: a **feeder** pushes cubes onto a **conveyor belt**, the belt carries each cube to an
**IR sensor**, and a **robot arm** picks it up and drops it in a bin. A **camera** watches the belt.

You can run it in two ways:

| Way | What runs | When to use it |
|---|---|---|
| **With the optimizer** (recommended) | vision + autoen + optimizer | normal work: saves energy, stops by itself when the feeder is empty, restarts by itself when you refill |
| **Independent** (autoen alone) | autoen (vision optional) | testing, calibration, or if the optimizer has a problem. Works like the old automation |

---

## 1. Quick start (with the optimizer)

```bash
cd ~/Desktop/PRISM
./start_cell.sh
```

The script starts everything in the right order and asks you before the arm moves:

1. starts the helpers that only watch and record: **health**, the **loggers** (`logger/arm.db`, `logger/camera.db`),
   the **arm and belt analyzers** and the **dashboard** (http://127.0.0.1:8080). `--no-extras` skips them
2. starts **vision** (camera), **autoen** (arm + belt) and the **optimizer**
3. checks that the optimizer can talk to autoen
4. tells you where autoen thinks the arm is (on the cradle or not) and asks you to confirm
5. **Enter = Start.** Before you press it: belt empty, cubes in the feeder, nobody near the arm, E-stop within reach

Then just keep the feeder filled. When it is empty, the cell stops and waits by itself; when you refill, it carries on
by itself (it tries one feed now and then to check).

**How the optimizer decides (every cycle), in this order:**

1. **Safety:** only settings that have proven they work; if a servo or the belt gets warm, only gentler settings;
   if hot, it pauses at home to cool down (mode COOL) and continues by itself when cool.
2. **Energy:** it keeps the settings within 5 % of the lowest energy per cube. It **measures** the energy of every
   setting live, and now and then tries a nearby safe setting for 4 cycles to keep its numbers up to date.
3. **Speed:** of those, it picks the fastest (today: 20 rpm, arm 1.5).

**Colour sorting:** the camera sees each cube's colour on the belt, and the optimizer sends it to its own bin:
**orange → left bin, white → right bin**. A cube the camera did not see goes to the right bin and is counted as
"colour not seen" in the report. To sort the old way (alternating bins), start the optimizer with `--no-sort`.

If no cube appears on the camera 3 s after a feed, it **feeds once more** at once (a missed push). If there is still
nothing, the feeder is empty: belt stopped, arm home.

**Feeder IR sensor (Mega D36, needs the new firmware):** when it reads "empty" for 2 s, the cell finishes the cube
on the belt and goes IDLE without an empty feed. When it reads "cubes" for 2 s while idle, it resumes at once. Until
it has been right 3 times, the probes still run as a backup. If it is ever wrong (it said cubes but the feed was
empty, or it said empty but a probe found a cube), the optimizer ignores it until the next start and says so in its
log. With the old firmware nothing changes.

**Stop everything:**

```bash
./stop_cell.sh          # stops the run, the optimizer and autoen (vision keeps running)
./stop_cell.sh --all    # also stops vision, health, the loggers, the analyzers and the dashboard
```

**Other ways to start:**

```bash
./start_cell.sh --no-auto   # the optimizer waits for you to say "resume" (see section 4)
./start_cell.sh --shadow    # the optimizer only writes down what it would do, it sends nothing
./start_cell.sh --no-extras # without health, loggers, analyzers and dashboard
```

The programs run in the background. Their output is in `~/Desktop/PRISM/run_logs/`. To watch the optimizer:

```bash
tail -f ~/Desktop/PRISM/run_logs/optimizer_*.log
```

---

## 2. Independent mode (autoen alone, no optimizer)

autoen is the program that drives the arm, the belt and the feeder. It works on its own.

```bash
cd ~/Desktop/PRISM/autoencoder
~/autoen-env/bin/python auto_en_new.py
```

A web page opens at **http://127.0.0.1:8781**. On it:

1. set the parameters (good values below)
2. tick **"arm area is clear"**
3. press **Start**

Good settings (measured as the best):

| Setting | Value |
|---|---|
| rpm (belt) | **20** |
| arm speed | **1.5** |
| carry speed | **1.5** |
| arrive timeout | **25** |
| sets / cycles per set | how many cubes you want (e.g. 100 / 100) |

**What is different without the optimizer:**

- when the feeder is empty, autoen keeps trying: 3 empty cycles (~25 s of belt each), then it **stops with an error**
- it never restarts by itself
- nothing saves energy while waiting

Vision is optional in this mode (autoen does not need the camera). To start it anyway:

```bash
cd ~/Desktop/PRISM/vision
~/prism-env/bin/python vision_live_tracks.py --colors white,orange --belt-dir -1
```

> **Important:** if you want the optimizer, it must be running **before** you press Start.
> If you start the optimizer after Start, autoen is already running on its own.

---

## 3. Starting each program by hand (instead of start_cell.sh)

Use three terminals, in this order:

```bash
# 1. camera
cd ~/Desktop/PRISM/vision && ~/prism-env/bin/python vision_live_tracks.py --colors white,orange --belt-dir -1

# 2. arm + belt
cd ~/Desktop/PRISM/autoencoder && ~/autoen-env/bin/python auto_en_new.py

# 3. optimizer (wait until it prints "autoen ready")
cd ~/Desktop/PRISM/orchestrator && ~/orch-env/bin/python main.py --auto-resume
```

Then press Start on the autoen page (http://127.0.0.1:8781).

Optimizer options:

| Option | What it does |
|---|---|
| *(none)* | live control; when the feeder is empty it waits for your `resume` |
| `--auto-resume` | live control; checks the feeder by itself when a refill is likely |
| `--shadow` | sends nothing, only logs what it would do (for testing) |
| `--objective priority` | default: 1 safety, 2 energy, 3 speed (see section 1) |
| `--objective energy` | fewest joules per cube, whatever the speed |
| `--objective throughput` | most cubes per minute, whatever the energy |
| `--no-sort` | no colour sorting: autoen uses its own bin order from its web page |
| `--no-brake` | when idle, leave the belt coasting instead of braking it |

---

## 4. Talking to the optimizer while it runs

Send commands from any terminal:

```bash
mosquitto_pub -t orchestrator/cmd -m resume   # carry on (after a refill, or after you fixed a problem)
mosquitto_pub -t orchestrator/cmd -m park     # put the arm on the cradle (only while paused)
mosquitto_pub -t orchestrator/cmd -m wake     # take the arm off the cradle (back to home)
```

What the optimizer is doing (its **mode**, shown in its log):

| Mode | Meaning | What you do |
|---|---|---|
| **RUN** | picking cubes at 20 rpm / arm 1.5 | nothing |
| **IDLE** | feeder empty: belt stopped, arm at home (~0.08 W) | refill the feeder (with `--auto-resume` it continues by itself) |
| **COOL** | a servo (≥ 65 °C) or the belt motor (≥ 57 °C) is too hot: paused at home | nothing: it continues when cool; if it happens often, check ventilation |
| **ALERT** | something went wrong (grip miss, fault, no reply from the Mega) | look at the cell, fix it, then send `resume` |
| **MANUAL** | someone paused autoen on its web page | the optimizer does nothing until autoen runs again |
| **PARK** | the arm rests on the cradle | send `wake` |
| **OFF** | autoen not running, not started, or an experiment is running | start autoen / press Start |

---

## 5. The arm and the cradle (safety)

The arm has a **rest pose on the cradle**. From the cradle, the arm must **not** drive straight home, or it hits the
frame. It must use the **wake** move (the path taught with `rest_teach.py`, ~36 s).

- autoen **remembers** whether the arm is resting, in `autoencoder/rest_state.json`, even after a restart or power cut
- `start_cell.sh` reads this and wakes the arm safely before the run starts
- if the arm is **not** really on the cradle (you moved it by hand), start autoen with `--awake`
- if the arm **is** on the cradle but autoen thinks it is awake, start autoen with `--resting`

```bash
~/autoen-env/bin/python auto_en_new.py --resting   # arm is on the cradle: Start moves nothing until wake
~/autoen-env/bin/python auto_en_new.py --awake     # arm is NOT on the cradle, whatever the file says
```

Resting does **not** save energy (the cradle pose uses ~0.30 W, home uses ~0.08 W). Use it to park the arm at the end of
the day, not while waiting for cubes.

---

## 6. Daily report

```bash
cd ~/Desktop/PRISM/orchestrator
~/orch-env/bin/python report.py              # today
~/orch-env/bin/python report.py 2026-10-26   # a given day
~/orch-env/bin/python report.py --week       # last 7 days, one line each
```

It shows: cubes picked, cubes per minute, joules per cube, idle power, how often the feeder ran empty, probes,
problems, and what the optimizer has learned. Reports are saved in `orchestrator/reports/`.

---

## 7. Start automatically when the Pi boots (optional)

```bash
cp ~/Desktop/PRISM/prism-cell.desktop ~/.config/autostart/    # turn on
rm ~/.config/autostart/prism-cell.desktop                     # turn off
```

After login, a "PRISM cell" window opens, starts everything and asks you **once** before the arm moves.

---

## 8. Experiments and calibration (advanced)

For measuring new settings, use `experiment.py` (the optimizer must **not** be in control; it switches itself OFF
when it sees an experiment):

```bash
cd ~/Desktop/PRISM/orchestrator/cal
~/orch-env/bin/python experiment.py run --plan plans/vision_check_v1.json --cubes "orange+white 40mm" --note "what you test"
```

After new experiment data, refit the model the optimizer uses:

```bash
cd ~/Desktop/PRISM/orchestrator
~/orch-env/bin/python model.py fit --runs cal/runs/<session>.jsonl ...
~/orch-env/bin/python model.py show
```

Camera colour calibration (only if the cubes or the light change):

```bash
cd ~/Desktop/PRISM/vision
~/prism-env/bin/python vision_live_tracks.py --calibrate --colors white,orange
```

Select the colour in the window **first**, then hold that cube under the camera. Never enable **green** (the belt is
green). Check that the pink tape on the belt edge is not detected.

---

## 9. Problems we have seen

| What you see | Why | What to do |
|---|---|---|
| belt runs again and again on an empty feeder, then autoen stops | the optimizer was not running when you pressed Start | start the optimizer first (or use `start_cell.sh`) |
| optimizer log says "autoen not reachable" | autoen is not running | start autoen |
| camera only counts white cubes | orange not calibrated / wrong colour saved | recalibrate orange (section 8), select "orange" before holding the cube |
| the optimizer never stops the belt early | camera not trusted yet (it must see 9 of the last 10 cubes) | check the camera window; it needs ~5 cubes after each start |
| ALERT "no reply to X,..." | a message from the Mega got lost | autoen now asks again by itself; if it still happens, check the USB cable |
| ALERT "GRIP_MISS" | the gripper closed on nothing | check the cube position and the gripper, then `resume` |
| belt power shows nothing (voltage empty) | INA260 not answering | the belt INA260 must be on SDA 20 / SCL 21 (there is no arm INA260) |
| arm on the cradle and autoen is about to Start | autoen does not know it rests | stop; start autoen with `--resting` |

---

## 10. Where things are

| Path | What |
|---|---|
| `start_cell.sh`, `stop_cell.sh` | start / stop everything |
| `autoencoder/auto_en_new.py` | autoen: arm, belt, feeder (web page :8781) |
| `autoencoder/rest_state.json` | autoen's memory: is the arm on the cradle? |
| `vision/vision_live_tracks.py` | camera node; colours in `vision/vision_calibration.json` |
| `orchestrator/main.py` | the optimizer (observe → predict → optimize → actuate) |
| `orchestrator/forecast_state.json` | what it learned about your refill times |
| `orchestrator/learned_state.json` | what it learned about which settings work |
| `orchestrator/logs/` | one log per optimizer run (plans, cycles, energy) |
| `orchestrator/reports/` | daily reports |
| `docs/OPTIMIZER_ROADMAP.md` | the full history: measurements, decisions, results |
| `orchestrator/test/` | tests that run without the robot |

Python environments: `~/autoen-env` (autoen), `~/prism-env` (vision), `~/orch-env` (optimizer, reports),
`~/db-env` (simulator tests).

Run all tests (no robot needed):

```bash
cd ~/Desktop/PRISM/orchestrator
~/orch-env/bin/python test/test_opt.py
~/orch-env/bin/python test/test_forecast.py
~/db-env/bin/python test/test_auto_sim.py
```
