#!/usr/bin/env python3
"""
autoen_node.py -- PRISM cell node: ARM + CONVEYOR + FEEDER in one program, with a web dashboard that asks for the
parameters and then runs the real pick cycle. (Pi 4 + Arduino Mega 2560.)

Built on riff-real.py (the cycle, the dashboard, the CSV recording are unchanged) and on arm_node.py (the MQTT side:
the same topics, so the Logger, the Health monitor and the Analyzers see this node exactly like the old arm node).

   Browser --HTTP--> autoen_node.py --USB serial--> Mega --> STS3215 x6 / belt motor / feeder servo / IR
                          |
                          +--MQTT--> Mosquitto --> Logger, Health monitor, Analyzer nodes

ONE cycle (riff-real, unchanged):  FEED > TRANSPORT (belt to the IR, arm to Standby) > GRIP > CARRY Home > drop >
RELEASE > HOME > CLEAR.   A "set" = --cycles-per-set cycles, the run = --sets sets.  Put the blocks in the feeder yourself.

HOW YOU USE IT
  python3 autoen_node.py                  opens http://127.0.0.1:8781 and WAITS: nothing moves.
  On the page: set every parameter, tick "arm area is clear", press Start.  Stop = belt coasts, arm holds.
  Command-line options are only the starting values of the page.  (--auto-start skips the page.)
  From another PC:  ssh -L 8781:127.0.0.1:8781 pi@<pi>   then open http://127.0.0.1:8781 on that PC.
  (The page can MOVE THE ROBOT and has no password: it listens on 127.0.0.1 only unless you pass --web-host.)

MQTT PUBLISHED  (broker = MQTT_HOST env var or --mqtt-host; --no-mqtt runs without a broker)
  arm/telemetry   10 Hz QoS0   {"ts","joints":{"1":{"pos","speed","cur","temp","volt"},..."6":{...}}}    raw units like arm_node:
                               pos = ticks, speed = ticks/s, cur = counts (x6.5 = mA), temp = degC (glitch-filtered),
                               volt = servo supply volts (omitted if not seen in the last 15 s).
                               Only when all six joints are fresh. A garbled current reading is replaced by the last good one.
  arm/state       retained     10 Hz {"ts","mode":"auto|hold|lock","speed_scale","pose","phase","cycle","status","drop"}
  arm/status      retained + Last Will                 arm/ir  retained, on change {"raw","detected"}
  arm/gripper     QoS1         {"state":"CLOSING|CLOSED|ERROR","pos","reason"}  on every gripper event
  belt/telemetry  on every Mega sample   {"ts","temp","current","velocity","position","voltage","pwm","ir","fault","feed_ir"}
                               current mA, velocity rpm, position rev: this is what belt_analyzer_node.py subscribes to
  belt/event      QoS1         {"ts","name","args"}  ARRIVED / FEED_DONE / FAULT ... (the feeder shows up here)
  belt/status     retained + Last Will
  autoen/state    retained 1 Hz   run status, phase, set, cycle, drifts, MQTT counters
  autoen/cycle    QoS1         one message per finished cycle {"n","set","result","secs","drop","notes"}

FILES (--log-dir, default riff_logs/): autoen_raw_<time>.csv, autoen_sets_<time>.csv, autoen_cycles_<time>.csv,
  autoen_thresholds_<time>.csv, autoen_tx_<time>.log   -- same columns as riff-real, so the same tools read them.

NOT included (on purpose): the keyboard jog of arm_node.py. Both programs cannot open the Mega at once, and a human
pressing keys during an automatic cycle would fight it. Use arm_node.py when you want to jog the arm by hand.
Not a safety-rated e-stop. Keep clear of the arm.

Known limits of the data (be aware when you set thresholds)
  * The Mega <-> servo link garbles a few % of replies.  Temperature jumps of more than 6 C are held back until a
    second reading confirms them; how many were rejected is counted in autoen_sets (temp_glitches).
  * Belt current/power are magnitudes.  With the encoder sign wrong, the belt speed loop runs at full PWM and "rpm"
    will look negative - that is part of the behaviour and is logged as is.
"""
import argparse
import csv
import glob
import json
import math
import os
import queue
import statistics
import threading
import time
import webbrowser
from collections import Counter
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import serial

try:
    import paho.mqtt.client as mqtt          # pip install paho-mqtt   (--no-mqtt runs without it)
except ImportError:
    mqtt = None

# ====================================================================== constants (same numbers the project uses)
DEVICES = ["J1", "J2", "J3", "J4", "J5", "J6", "Belt", "Arm"]      # Arm = derived: sum of the six servo currents, lowest servo voltage (no INA on the arm supply)
METRICS = ["temp", "current", "velocity", "position", "voltage"]
UNITS = {"voltage": "V", "temp": "C", "current": "mA", "velocity": "deg/s (belt: rpm)", "position": "deg (belt: rev)"}
STEPS_PER_REV = 4096.0            # STS3215 position steps per revolution
MA_PER_COUNT = 6.5                # STS3215 current register unit
MIN_WRITE_GAP_S = 0.010           # the Mega needs >= 10 ms between two lines
KEEPALIVE_S = 0.2                 # watchdogs: arm 350 ms, belt 500 ms -> heartbeat every 0.2 s
POSE_TOL_TICKS = 40               # a joint counts as "arrived" inside this window
GRIP_TOL_TICKS = 25               # same idea for the gripper
BASE_SPEED = 360                  # raw ticks/s at arm-speed 1.0
GRIPPER_SPEED = 1200
GRIPPER_MIN, GRIPPER_MAX = 1768, 3116     # the Mega clamps to these anyway
MAX_VALID_MA = 6000.0             # STS3215 stalls at ~3 A; anything above is a corrupted reading
STALE_S = 3.0                     # a reading older than this is shown as "no data"
TEMP_JUMP_C = 6.0                 # hold back temperature jumps larger than this until confirmed
# Same idea as TEMP_JUMP_C, for current: a single garbled byte in a "T,<id>,pos,speed,current" reply can
# produce one wildly-wrong-but-still-under-MAX_VALID_MA reading (measured: 1898/2028 mA spikes with zero
# matching position movement, i.e. nothing physically happened). A REAL current step (motor starting to
# move, a genuine stall) stays elevated across several consecutive samples; a glitch reverts on the very
# next one -- that difference is what CURRENT_JUMP_MA/CURRENT_CONFIRM_MA tell apart, same mechanism as the
# temperature filter above. This can delay a genuine fast current step by one sample in the log/thresholds;
# nothing in the control loop reads "current" for a live decision, so that lag has no safety effect.
CURRENT_JUMP_MA = 400.0
CURRENT_CONFIRM_MA = 150.0
STS_MAX_TICKS_S = 3200             # STS3215 hardware maximum (ticks/s)
CARRY_CAP_TICKS_S = STS_MAX_TICKS_S   # no extra cap while carrying (was 700); lower Carry speed on the page if the block slips
BELT_FIELDS = 17                  # values after "X,T" (older firmware)
BELT_FIELDS_FEED_IR = 18          # ... + the feeder IR on D36 (new firmware)
MAG_STALE_S = 2.0                 # the other D36 firmware repeats "M,<0|1>" every 0.5 s; older = no signal
TELEMETRY_TIMEOUT_S = 1.5         # a servo reading older than this is not "fresh" (arm/telemetry is not published)

# The four poses (raw ticks, joints 1-6), the same numbers as STATES in arm_node.py. riff-real calls them by the names of
# its old d-pad file: up = standby above the block, right = home, left = left bin, down = right bin.
# --poses FILE replaces them with a so101_dpad_poses.json.
DEFAULT_POSES = {
    "up":    {"1": 2103, "2": 1662, "3": 2357, "4": 3009, "5": 1239, "6": 2844},    # standby
    "right": {"1": 2069, "2": 1478, "3": 2172, "4": 3190, "5": 1230, "6": 2105},    # home
    "down":  {"1": 3079, "2": 1932, "3": 1847, "4": 3116, "5": 2081, "6": 2111},    # right bin
    "left":  {"1": 1039, "2": 1774, "3": 2071, "4": 3196, "5": 303,  "6": 2108},    # left bin
}
# config/poses.json: extra poses (rest) + the ordered rest / wake moves; see load_pose_config()
POSE_CONFIG = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "config", "poses.json")
# The arm's rest state survives restarts here: a fresh autoen that believes "awake" while the arm is on the cradle
# drives Home through the frame. Written on every change (rest / wake), read at startup. '' = no memory (simulator).
REST_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "rest_state.json")
RX_GAP_NOTE_S = 0.3               # the Mega streams telemetry all the time: silence longer than this = its loop() was blocked
GRIP_POS_STILL_S = 0.3            # --grip-pos: J6 not moving this long short of grip_pos = it is on a wider block
GRIP_POS_SHORT_SQUEEZE = 10       # ... then hold this many ticks past where it stopped (light grip, not a full-torque push)
GRIP_POS_NOT_STARTED = 30         # ... unless it got less than this far toward grip_pos: the move never began, resend it
CARRY_SETTLE_S = 0.35            # J6 samples this soon after a carry starts are ignored by the slip / hold-current check


class CycleError(Exception):
    """A cycle that did not complete; .code is the result written to the cycles file."""
    def __init__(self, code, text):
        super().__init__(text)
        self.code = code


# ====================================================================== serial link (minimal, standalone)
class Link:
    """Talks to the Mega: reads T / TT / X,T / X,E lines, sends commands, keeps the watchdogs fed."""

    def __init__(self, port, baud=115200, ser=None):
        self.ser = ser or serial.Serial(port, baud, timeout=0.1)
        self.boot_seen, self.boot_lines = False, []
        end = time.monotonic() + 12.0
        # opening the port resets the Mega: wait for its banner before writing anything
        while time.monotonic() < end and not self.boot_seen:
            raw = self.ser.readline()
            if raw:
                text = raw.decode("ascii", errors="ignore").strip()
                self.boot_lines.append(text)
                self.boot_seen = "BOOT_DONE" in text or text.startswith("H,SO101")
        time.sleep(0.2)
        self.ser.reset_input_buffer()

        self.wlock, self.last_write = threading.Lock(), 0.0
        self.txlog, self.txlock = None, threading.Lock()      # set by main(): file with every command sent + odd replies
        self.bad_rx = 0                                       # received lines that could not be parsed
        self.slock = threading.Lock()                       # protects the parsed state below
        self.torque = {}                                    # servo id -> (1 on | 0 off, present ticks, monotonic t) from Q replies
        self.servo = {i: {"pos": None, "speed": 0, "cur": 0, "t": 0.0, "temp": None, "volt": None, "tv": 0.0}
                      for i in range(1, 7)}
        self.belt, self.belt_t = None, 0.0
        self.mag, self.mag_t = None, 0.0                    # feeder IR from "M,<0|1>" lines: True = cube there
        self.firmware_ready = None
        self.replies, self.events = queue.Queue(), queue.Queue()
        self.gpub = queue.Queue(maxsize=500)                # copies for MQTT (bounded: nobody may be listening)
        self.epub = queue.Queue(maxsize=500)
        self.gevents = queue.Queue()                        # gripper crawl results: (state, pos, torque_limit_readback_or_None)
        # diagnostics for the belt-watchdog FAULT (FAULT_1): was it the PC that went quiet, or the Mega that stopped listening?
        self.hb_last = time.monotonic()                     # when the last X,HB (the belt's keep-alive) was written
        self.rx_last = time.monotonic()                     # when ANY line last arrived from the Mega
        self.rx_gaps = []                                   # recent silences of the Mega: (monotonic time, seconds)
        self.running = True
        threading.Thread(target=self._rx_loop, daemon=True).start()
        threading.Thread(target=self._hb_loop, daemon=True).start()

    # ---------------------------------------------------------------- writing
    def note(self, text):
        """Write one line (with a time stamp) to the TX log, if it is open."""
        if self.txlog:
            with self.txlock:
                self.txlog.write(f"{datetime.now().strftime('%H:%M:%S.%f')[:-3]} {text}\n")

    def write(self, line, hb=False):
        with self.wlock:                                    # one writer at a time, paced
            wait = self.last_write + MIN_WRITE_GAP_S - time.monotonic()
            if wait > 0:
                time.sleep(wait)
            self.ser.write((line + "\n").encode("ascii"))
            self.last_write = time.monotonic()
            if not hb:                                      # heartbeats would drown everything else
                self.note("TX " + line)

    def _hb_loop(self):
        while self.running:
            try:
                self.write("X,HB", hb=True)                  # belt watchdog (silent)
                self.hb_last = time.monotonic()               # remembered so a FAULT can say how old the last HB was
                for sid in range(1, 7):
                    self.write(f"J,{sid},0", hb=True)         # arm watchdog, harmless at rate 0
            except Exception:                               # noqa: BLE001 - port closed
                break
            time.sleep(KEEPALIVE_S)

    NO_RESEND = ("FEED",)   # not safe to send twice: a lost reply to FEED may still have pushed a block

    def belt_cmd(self, cmd, timeout=1.0):
        """Send 'X,<cmd>' and return 'OK' or raise. ERR,unknown_cmd means the line was garbled in transit: ask again.
        No reply at all (~1 in a few hundred commands, 2026-10-24..26) is asked again too, except for NO_RESEND."""
        resend = cmd.split(",")[0] not in self.NO_RESEND
        for attempt in range(4):
            while not self.replies.empty():                 # drop stale replies
                self.replies.get_nowait()
            self.write("X," + cmd)
            try:
                r = self.replies.get(timeout=timeout)
            except queue.Empty:
                if not resend or attempt >= 2:
                    raise TimeoutError(f"no reply to X,{cmd}")
                self.note(f"## no reply to X,{cmd}: sending it again")
                continue
            if r != "ERR,unknown_cmd":
                break
            time.sleep(0.1)
        if r not in ("OK", "PONG"):
            raise RuntimeError(f"X,{cmd} -> {r}")

    # ---------------------------------------------------------------- reading
    def _rx_loop(self):
        while self.running:
            try:
                raw = self.ser.readline()
            except Exception:                               # noqa: BLE001 - port closed
                break
            if raw:
                now = time.monotonic()
                gap = now - self.rx_last
                self.rx_last = now
                if gap > RX_GAP_NOTE_S:
                    # The Mega prints telemetry continuously, so a long silence means its loop() was stuck (blocking servo
                    # reads that time out on the noisy bus, say) -- the prime suspect for a belt watchdog FAULT while the PC
                    # kept sending X,HB. Written to the TX log so it can be lined up with the FAULT line.
                    self.rx_gaps = [g for g in self.rx_gaps if now - g[0] < 5.0] + [(now, gap)]
                    self.note(f"## RX GAP {gap:.2f}s - the Mega sent nothing (its loop was blocked?)")
                line = raw.decode("ascii", errors="ignore").strip()
                if line:
                    self._parse(line)

    def _parse(self, line):
        p = line.split(",")
        try:
            if p[0] == "T" and len(p) == 5:                 # T,id,pos,speed,current
                sid, pos = int(p[1]), int(p[2])
                with self.slock:
                    if sid in self.servo:
                        s = self.servo[sid]
                        s.update(pos=pos if 0 <= pos <= 4095 else None, speed=int(p[3]), cur=int(p[4]),
                                 t=time.monotonic())
            elif p[0] == "TT" and len(p) == 4:              # TT,id,temp_C,volt_x10  (slow, one servo at a time)
                sid = int(p[1])
                with self.slock:
                    if sid in self.servo:
                        s = self.servo[sid]
                        s["temp"] = int(p[2]) if int(p[2]) > 0 else None
                        s["volt"] = int(p[3]) / 10.0 if int(p[3]) > 0 else None
                        s["tv"] = time.monotonic()
            elif p[0] == "G" and len(p) >= 3:                # G,<CLOSING|CLOSED|ERROR>,<pos>[,<torque_limit_readback>]
                # 3rd field (feature D): the Mega reads the torque limit back after writing it, so a dropped write is visible
                torque_readback = int(p[3]) if len(p) >= 4 and p[3].lstrip("-").isdigit() else None
                gpos = int(p[2]) if p[2].lstrip("-").isdigit() else None
                self.gevents.put((p[1], gpos, torque_readback))
                self.note("RX " + line)                      # G,CLOSED/ERROR with the position: needed to judge grips afterwards
                self._offer(self.gpub, {"state": p[1], "pos": gpos, "torque_readback": torque_readback,
                                        "reason": ",".join(p[3:]) if len(p) > 3 and torque_readback is None else None})
            elif p[0] == "M" and len(p) >= 2 and p[1] in ("0", "1"):   # M,<1 = cube in the feeder | 0 = empty> (D36)
                with self.slock:
                    self.mag, self.mag_t = p[1] == "1", time.monotonic()
            elif p[0] == "R" and len(p) >= 2:
                self.firmware_ready = p[1] == "1"
            elif p[0] == "Q" and len(p) == 4:                # Q,id,<1 torque on|0 off>,<present or -1>: reply to Q,id,0|1
                self.note("RX " + line)
                with self.slock:
                    self.torque[int(p[1])] = (int(p[2]), int(p[3]), time.monotonic())
            elif p[0] == "X" and len(p) >= 2:
                if p[1] == "T" and len(p) - 2 in (BELT_FIELDS, BELT_FIELDS_FEED_IR):
                    f = p[2:]
                    d = {"ms": int(f[0]), "enc": int(f[1]), "rpm": float(f[2]), "pwm": int(f[3]), "mode": int(f[4]),
                         "ma": float(f[5]), "mv": float(f[6]), "arm_ma": float(f[8]), "arm_mv": float(f[9]),
                         "temp": float(f[11]), "ir": f[12] == "1",
                         "fault": int(f[14]), "feed": int(f[16]),
                         "feed_ir": (f[17] == "1") if len(f) > BELT_FIELDS else None}   # None = old firmware
                    with self.slock:
                        self.belt, self.belt_t = d, time.monotonic()
                elif p[1] == "E" and len(p) >= 4:
                    self.note("RX " + line)                  # ARRIVED / FEED_DONE / FAULT with the Mega's own clock
                    if p[2] == "FAULT":
                        now = time.monotonic()
                        b = self.belt or {}
                        recent = ", ".join(f"{g:.2f}s@-{now - t:.1f}s" for t, g in self.rx_gaps if now - t < 3.0) or "none"
                        self.note(f"## FAULT diag: code={p[4] if len(p) > 4 else '?'} (1 watchdog 2 overtemp 3 temp-sensor 4 stall) "
                                  f"last X,HB written {now - self.hb_last:.2f}s ago | Mega silent gaps in the last 3 s: {recent} | "
                                  f"belt pwm={b.get('pwm')} rpm={b.get('rpm')} mA={b.get('ma')} mode={b.get('mode')}")
                    self.events.put((p[2], p[4:]))          # name, args
                    self._offer(self.epub, {"name": p[2], "args": p[3:]})
                elif p[1] in ("OK", "ERR", "PONG"):
                    if p[1] == "ERR":
                        self.note("RX " + line)              # e.g. fault_latched_send_STOP, feeder_busy
                    self.replies.put(",".join(p[1:]))
                elif p[1] == "VER":
                    self.note("RX " + line)                  # which build is on the board and which diagnostic switches are on
        except ValueError:
            self.bad_rx += 1                                # garbled line: drop it, but keep a record
            self.note("RX? " + line[:80])

    @staticmethod
    def _offer(q, item):
        try:
            q.put_nowait(item)
        except queue.Full:                                  # nobody drains it (MQTT off): drop, never block the reader
            pass

    def servo_pos(self, sid, max_age=1.5):
        with self.slock:
            s = self.servo[sid]
            return s["pos"] if s["pos"] is not None and time.monotonic() - s["t"] <= max_age else None

    def servo_speed(self, sid):
        with self.slock:
            return self.servo[sid]["speed"]

    def wait_ready(self, timeout=20.0):
        end, why = time.monotonic() + timeout, "nothing received yet"
        while time.monotonic() < end:
            miss = [i for i in range(1, 7) if self.servo_pos(i, 1.5) is None]
            if self.firmware_ready is not True:
                why = f"no 'R,1' from the arm firmware (state {self.firmware_ready})"
            elif miss:
                why = f"no fresh position for servo(s) {miss}"
            else:
                try:
                    self.belt_cmd("PING")
                    return
                except (TimeoutError, RuntimeError) as e:
                    why = f"belt module did not answer PING ({e})"
            time.sleep(0.2)
        raise TimeoutError(f"Mega not ready after {timeout:.0f}s: {why}. boot banner seen: {self.boot_seen}")

    def close(self):
        try:
            self.belt_cmd("STOP")                           # never leave the belt running
        except Exception:                                   # noqa: BLE001
            pass
        self.running = False
        try:
            self.ser.close()
        except Exception:                                   # noqa: BLE001
            pass


# ====================================================================== readings of every device
class Reader:
    """Turns the link's raw state into (temp, current, velocity, position) per device, with a temperature AND a current glitch filter."""

    def __init__(self, link, cpr):
        self.link, self.cpr = link, cpr
        self.tstate = {d: {"good": None, "cand": None, "cand_tv": 0.0} for d in DEVICES}
        self.glitches = {d: 0 for d in DEVICES}
        self.cstate = {d: {"good": None, "cand": None, "cand_tv": 0.0} for d in DEVICES}
        self.current_glitches = {d: 0 for d in DEVICES}   # single-sample current spikes held back (see CURRENT_JUMP_MA)
        self.bad_current = {d: 0 for d in DEVICES}       # garbled current readings dropped
        self.rlock = threading.Lock()                    # the sampler and the MQTT publisher both call read()

    def _temp(self, dev, t, stamp):
        st = self.tstate[dev]
        if t is None or not (0 < t < 125):
            return st["good"]
        if st["good"] is None or abs(t - st["good"]) <= TEMP_JUMP_C:
            st["good"], st["cand"] = t, None
        elif st["cand"] is not None and abs(t - st["cand"]) <= 2 and stamp != st["cand_tv"]:
            st["good"], st["cand"] = t, None                # a newer reading confirms the jump: it is real
        else:
            if st["cand"] is None or stamp != st["cand_tv"]:
                self.glitches[dev] += 1                     # count each held-back outlier once
            st["cand"], st["cand_tv"] = t, stamp
        return st["good"]

    def _current(self, dev, ma, stamp):
        """Same hold-back-until-confirmed technique as _temp (see CURRENT_JUMP_MA above for why)."""
        st = self.cstate[dev]
        if ma is None:
            return st["good"]
        if st["good"] is None or abs(ma - st["good"]) <= CURRENT_JUMP_MA:
            st["good"], st["cand"] = ma, None
        elif st["cand"] is not None and abs(ma - st["cand"]) <= CURRENT_CONFIRM_MA and stamp != st["cand_tv"]:
            st["good"], st["cand"] = ma, None                # a newer reading confirms the jump: it is real
        else:
            if st["cand"] is None or stamp != st["cand_tv"]:
                self.current_glitches[dev] += 1              # count each held-back outlier once
            st["cand"], st["cand_tv"] = ma, stamp
        return st["good"]

    def read(self):
        """-> {device: {metric: value or None}}"""
        with self.rlock:
            return self._read()

    def _read(self):
        out, now = {}, time.monotonic()
        with self.link.slock:
            servos = {i: dict(s) for i, s in self.link.servo.items()}
            belt, belt_t = (dict(self.link.belt) if self.link.belt else None), self.link.belt_t
        for i in range(1, 7):
            s, dev = servos[i], f"J{i}"
            if s["pos"] is None or now - s["t"] > STALE_S:
                out[dev] = {m: None for m in METRICS}
                continue
            fresh_t = s["temp"] if now - s["tv"] < 15.0 else None
            raw_cur = s["cur"] & 0x7FFF                                       # bit 15 = direction: keep magnitude
            ma = raw_cur * MA_PER_COUNT
            if ma > MAX_VALID_MA:                                             # 0x7FFF etc. = garbled reply, not a real current
                ma, self.bad_current[dev] = None, self.bad_current[dev] + 1
            out[dev] = {"temp": self._temp(dev, fresh_t, s["tv"]),
                        "current": self._current(dev, ma, s["t"]),
                        "velocity": s["speed"] * 360.0 / STEPS_PER_REV,
                        "position": s["pos"] * 360.0 / STEPS_PER_REV,
                        "voltage": s["volt"] if now - s["tv"] < 15.0 else None}      # TT line: servo supply seen by that servo
        if belt is None or now - belt_t > 2.0:
            out["Belt"] = {m: None for m in METRICS}
        else:
            t = belt["temp"]
            belt_ma = abs(belt["ma"])
            out["Belt"] = {"temp": self._temp("Belt", None if math.isnan(t) else t, belt["ms"]),
                           "current": self._current("Belt", None if math.isnan(belt_ma) else belt_ma, belt["ms"]),
                           "velocity": belt["rpm"], "position": belt["enc"] / self.cpr,
                           "voltage": None if math.isnan(belt["mv"]) else belt["mv"] / 1000.0}   # dead INA260 = nan: no value, not a poison pill

        cur = [out[f"J{i}"]["current"] for i in range(1, 7)]
        volt = [out[f"J{i}"]["voltage"] for i in range(1, 7) if out[f"J{i}"]["voltage"] is not None]
        out["Arm"] = {"temp": None, "velocity": None, "position": None,
                      "current": sum(cur) if all(c is not None for c in cur) else None,     # total arm current
                      "voltage": min(volt) if volt else None}                              # weakest supply seen by a servo
        return out


# ====================================================================== statistics helpers
def pct(sorted_vals, q):
    """Percentile q (0..100) of an already sorted list (nearest-rank)."""
    return sorted_vals[min(len(sorted_vals) - 1, max(0, int(math.ceil(q / 100.0 * len(sorted_vals))) - 1))]


def stats(vals):
    """min / mean / std / p50 / p95 / p99 / max of a list, rounded; None if empty."""
    vals = [x for x in vals if math.isfinite(x)]         # a nan used to make statistics.pstdev raise ValueError
    if not vals:
        return None
    v = sorted(vals)
    mean = statistics.fmean(v)
    sd = statistics.pstdev(v) if len(v) > 1 else 0.0
    r = lambda x: round(x, 2)
    return {"n": len(v), "min": r(v[0]), "mean": r(mean), "std": r(sd), "p50": r(pct(v, 50)), "p95": r(pct(v, 95)),
            "p99": r(pct(v, 99)), "max": r(v[-1]), "mean_plus_3sd": r(mean + 3 * sd)}


# ====================================================================== MQTT (same topics as arm_node.py)
class Mqtt:
    """Two broker connections, so each has its own Last Will: 'arm' (arm/status) and 'belt' (belt/status).
    Publishing never blocks the control loop and never raises: a missing broker only means no messages."""

    def __init__(self, host, port):
        self.host, self.port = host, port
        self.sent = Counter()
        self.up = {"arm": False, "belt": False}
        self.c = {"arm": self._client("autoen_arm", "arm", "arm/status"),
                  "belt": self._client("autoen_belt", "belt", "belt/status")}

    def _client(self, cid, key, status_topic):
        c = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id=cid)
        c.will_set(status_topic, json.dumps({"online": False}), qos=1, retain=True)    # sent by the broker if we die

        def on_connect(client, userdata, flags, reason_code, properties):
            self.up[key] = True
            print(f"[mqtt] {key} connected to {self.host}:{self.port}: {reason_code}", flush=True)
            client.publish(status_topic, json.dumps({"online": True, "ts": time.time()}), qos=1, retain=True)

        def on_disconnect(client, userdata, flags, reason_code, properties):
            self.up[key] = False
            print(f"[mqtt] {key} lost the broker", flush=True)

        def on_fail(client, userdata):                      # connect_async retries forever and silently: say so
            print(f"[mqtt] cannot reach the broker at {self.host}:{self.port} - retrying", flush=True)

        c.on_connect, c.on_disconnect, c.on_connect_fail = on_connect, on_disconnect, on_fail
        c.connect_async(self.host, self.port, keepalive=10)
        c.loop_start()
        return c

    def pub(self, key, topic, payload, qos=0, retain=False):
        try:
            self.c[key].publish(topic, json.dumps(payload), qos=qos, retain=retain)
            self.sent[topic] += 1
        except Exception:                                   # noqa: BLE001 - control must never depend on the broker
            pass

    def cycle(self, entry):
        self.pub("arm", "autoen/cycle", {"ts": time.time(), **entry}, qos=1)

    def info(self):
        return {"host": self.host, "port": self.port, "arm_up": self.up["arm"], "belt_up": self.up["belt"],
                "sent": sum(self.sent.values())}

    def close(self):
        for key, topic in (("arm", "arm/status"), ("belt", "belt/status")):
            try:        # wait_for_publish raises if the broker was never reachable; shutdown must still finish
                self.c[key].publish(topic, json.dumps({"online": False, "ts": time.time()}),
                                    qos=1, retain=True).wait_for_publish(1.0)
            except Exception:                               # noqa: BLE001
                pass
            self.c[key].loop_stop()
            self.c[key].disconnect()


class Publisher(threading.Thread):
    """Reads the link and publishes. Runs all the time (also while the page waits for Start), so the dashboard and the
    other nodes see live data before and after a run. Only reads shared state; it never writes to the Mega."""

    def __init__(self, study, mq, hz):
        super().__init__(daemon=True)
        self.study, self.mq, self.hz = study, mq, hz
        self.stop_evt = threading.Event()
        self.last_cur = {}                                  # servo -> last plausible current (counts)
        self.last_belt_ms, self.last_ir = None, None

    @staticmethod
    def _feed_ir(link, belt):
        """Feeder IR (D36): the firmware's "M,<0|1>" line if one is recent, else the 18th X,T value, else None."""
        with link.slock:
            if link.mag is not None and time.monotonic() - link.mag_t <= MAG_STALE_S:
                return link.mag
        return belt["feed_ir"]

    def run(self):
        link, last_state = self.study.link, 0.0
        while not self.stop_evt.is_set():
            t0 = time.monotonic()
            try:
                self.step(link, t0)
                if t0 - last_state >= 1.0:
                    last_state = t0
                    self.state()
            except Exception as e:                          # noqa: BLE001 - one bad message must not kill the publisher
                print("[mqtt] publisher error:", e, flush=True)
            self.stop_evt.wait(max(0.0, 1.0 / self.hz - (time.monotonic() - t0)))

    def step(self, link, now):
        with link.slock:
            servos = {i: dict(v) for i, v in link.servo.items()}
            belt, belt_t = (dict(link.belt) if link.belt else None), link.belt_t
        vals = self.study.reader.read()                     # glitch-filtered temperatures (and the Belt temp)
        # ---- arm/telemetry: only when all six joints are fresh (never publish stale numbers as live)
        if all(v["pos"] is not None and now - v["t"] <= TELEMETRY_TIMEOUT_S for v in servos.values()):
            joints = {}
            for i, v in servos.items():
                cur = v["cur"] & 0x7FFF                     # bit 15 = direction: keep the magnitude, like riff-real
                if cur * MA_PER_COUNT > MAX_VALID_MA:       # 0x7FFF etc. = a garbled reply: keep the last good value
                    cur = self.last_cur.get(i, 0)
                else:
                    self.last_cur[i] = cur
                j = {"pos": v["pos"], "speed": v["speed"], "cur": cur}
                t = vals[f"J{i}"]["temp"]
                if t is not None:
                    j["temp"] = t
                if v["volt"] is not None:
                    j["volt"] = v["volt"]
                joints[str(i)] = j
            self.mq.pub("arm", "arm/telemetry", {"ts": time.time(), "joints": joints})
        self.arm_state()
        # ---- belt/telemetry: once per NEW Mega sample (repeating one would corrupt the speed slope the analyzer measures)
        if belt is not None and now - belt_t <= 2.0 and belt["ms"] != self.last_belt_ms:
            self.last_belt_ms = belt["ms"]
            bv = vals["Belt"]
            self.mq.pub("belt", "belt/telemetry", {
                "ts": time.time(), "temp": bv["temp"], "current": bv["current"], "velocity": bv["velocity"],
                "position": bv["position"], "voltage": bv["voltage"], "pwm": belt["pwm"], "mode": belt["mode"],
                "ir": belt["ir"], "fault": belt["fault"], "feed_ir": self._feed_ir(link, belt),
                "arm_current": belt["arm_ma"], "arm_voltage": round(belt["arm_mv"] / 1000.0, 3)})   # arm-supply INA260 (mA, V)
            if belt["ir"] != self.last_ir:                  # arm/ir keeps arm_node's meaning: LOW (raw 0) = detected
                self.last_ir = belt["ir"]
                self.mq.pub("arm", "arm/ir", {"ts": time.time(), "raw": 0 if belt["ir"] else 1,
                                              "detected": bool(belt["ir"])}, qos=1, retain=True)
        # ---- events from the Mega
        while True:
            try:
                ev = link.gpub.get_nowait()
            except queue.Empty:
                break
            self.mq.pub("arm", "arm/gripper", {"ts": time.time(), **ev}, qos=1)
        while True:
            try:
                ev = link.epub.get_nowait()
            except queue.Empty:
                break
            self.mq.pub("belt", "belt/event", {"ts": time.time(), **ev}, qos=1)

    def arm_state(self):
        """arm/state at the telemetry rate (10 Hz): health_monitor expects arm_node's rate and goes STALE at 1 s."""
        st = self.study
        mode = ("lock" if st.status in ("starting", "error") else
                "auto" if st.status in ("preparing", "running", "paused") else "hold")
        self.mq.pub("arm", "arm/state", {"ts": time.time(), "mode": mode, "speed_scale": st.args.arm_speed,
                                         "pose": st.phase, "phase": st.phase, "cycle": st.cycle_total,
                                         "status": st.status, "drop": st.cycle_info.get("drop", ""),
                                         "rest": st.rest_state}, retain=True)

    def state(self):
        st = self.study
        self.mq.pub("arm", "autoen/state", {"ts": time.time(), "status": st.status, "phase": st.phase,
                                            "drop": st.cycle_info.get("drop", ""),
                                            "set": st.set_no, "sets": st.args.sets, "cycle_in_set": st.cycle_in_set,
                                            "cycles_per_set": st.args.cycles_per_set, "cycle_total": st.cycle_total,
                                            "drifts": st.total_excursions, "bad_rx": st.link.bad_rx,
                                            "message": st.message}, retain=True)


def load_pose_config(path):
    """config/poses.json -> dict (rest pose + rest/wake sequences), or None when there is no file / path is ''.
    A broken file stops autoen at startup (a wrong rest move is worse than no rest move)."""
    if not path or not os.path.exists(path):
        return None
    with open(path, encoding="utf-8") as f:
        cfg = json.load(f)
    rest = cfg.get("rest") or {}
    if sorted(rest) != [str(i) for i in range(1, 7)]:
        raise SystemExit(f"{path}: 'rest' needs joints 1..6")
    for key in ("rest_sequence", "wake_sequence"):
        steps = cfg.get(key)
        if not steps or not isinstance(steps, list):
            raise SystemExit(f"{path}: '{key}' must be a non-empty list of steps")
        for s in steps:
            if not s.get("name") or not s.get("joints") or any(k not in "123456" or len(k) != 1 for k in s["joints"]):
                raise SystemExit(f"{path}: {key} step {s!r} needs a name and joints 1..6")
            if any(not 0 <= int(v) <= 4095 for v in s["joints"].values()):
                raise SystemExit(f"{path}: {key} step {s['name']}: ticks must be 0..4095")
    last = {}
    for s in cfg["rest_sequence"]:
        last.update(s["joints"])
    if any(int(last.get(str(i), -1)) != int(rest[str(i)]) for i in range(1, 6)):
        raise SystemExit(f"{path}: rest_sequence must end exactly on the rest pose (J1-5)")
    if any(int(j) not in range(1, 7) for j in cfg.get("torque_off_joints", [])):
        raise SystemExit(f"{path}: torque_off_joints must be servo ids 1..6")
    return cfg


# ====================================================================== the study run
def initial_rest_state(args):
    """--resting or --awake win; otherwise what rest_state.json remembers; no file = awake."""
    if getattr(args, "resting", False):
        return "resting"
    if getattr(args, "awake", False) or not getattr(args, "rest_file", ""):
        return "awake"
    try:
        with open(args.rest_file, encoding="utf-8") as f:
            st = json.load(f).get("rest_state", "awake")
    except (OSError, ValueError):
        return "awake"
    return st if st in ("awake", "resting", "resting_torque_off") else "resting"   # unknown: assume the safe one


class Study:
    @property
    def rest_state(self):
        return self._rest_state

    @rest_state.setter
    def rest_state(self, value):
        """Every change is saved at once (atomic write), so a restart knows where the arm is."""
        self._rest_state = value
        path = getattr(self.args, "rest_file", "")
        if not path:
            return
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"rest_state": value, "since": datetime.now().isoformat(timespec="seconds")}, f)
        os.replace(tmp, path)

    def __init__(self, link, args, poses, stamp, mq=None):
        self.link, self.args, self.poses, self.mq = link, args, poses, mq
        self.reader = Reader(link, args.cpr)
        self.hold = {}                                      # joints 1-5 -> ticks of the pose the arm should be holding now
        self.exc_open = {}                                  # joint -> True while a drift away from the hold pose is open
        self.exc_last = {}                                  # joint -> time of the last corrective P
        self.cycle_notes = []                               # events of the cycle in progress (drift, settled ...)
        self.total_excursions = 0
        self._rest_state = "awake"                          # awake | resting | resting_torque_off  (tasks rest / wake)
        self.rest_state = initial_rest_state(args)          # --resting / --awake / rest_state.json; saved on every change
        self.stop_evt = threading.Event()
        self.start_evt = threading.Event()
        self.pause_evt = threading.Event()                  # set = hold the loop between cycles
        # experiment.py (cal/): while paused, POST /api/task queues ONE job (belt_run / hold_pose / idle) that the run thread
        # executes itself, so nothing else ever drives the Mega concurrently. self.task = the last job + its result.
        self.tasks = queue.Queue()
        self.task = None
        self.set_boundary = False                           # True only while pause_before_set holds between two sets
        self.phase_times, self._phase_t0 = {}, time.monotonic()
        self.bg_abort = threading.Event()                   # set = the pipelined cycle's helper threads must stop quietly
        self.transport_abort = threading.Event()            # POST /api/abort_transport: the orchestrator's camera saw no block fed
        self.warnings = []                                  # shown on the web page (e.g. belt INA260 silent)
        # feature C (belt queue, --enable-c): how many EXTRA blocks ride the belt behind the one at the IR.
        #   0 = none yet (the next cycle may prime), 1 = one queued ~half a belt behind the IR, None = unknown (after a
        #   failure/recovery: no more priming, the pipeline just carries on). q_tfull = the full-belt travel time measured
        #   on a cycle that had no queue; the prime feed is dropped queue_split * q_tfull after CONV starts.
        self.q_extra, self.q_tfull = 0, None
        self.tail_hist, self.trav_hist = [], []             # arrival guard: last 3 arm tails / belt travel times (s)
        self.belt_ina_bad = 0                               # consecutive samples with no belt current although belt telemetry is alive
        self.cycle_info = self.new_cycle_info()
        # feature D monitoring: min/max J6 current (mA) and position (deg) seen during the CARRY phases of
        # the cycle in progress, so a block slipping or being over-squeezed shows up without having to grep
        # the full raw CSV. Reset at the start of every one_cycle(); filled in by _sample() below.
        self.j6_carry = {"cur_min": None, "cur_max": None, "pos_min": None, "pos_max": None}
        self.applied = {}                                   # belt settings last sent to the Mega
        self.lock = threading.Lock()
        self._phase = "IDLE"
        self.set_no, self.cycle_in_set, self.cycle_total = 1, 0, 0
        self.status, self.message = "starting", ""
        self.live = {d: {m: None for m in METRICS} for d in DEVICES}
        self.all_vals = {d: {m: [] for m in METRICS} for d in DEVICES}      # every sample, for thresholds
        self.set_vals = {d: {m: [] for m in METRICS} for d in DEVICES}      # samples of the current set
        self.set_glitch0 = dict(self.reader.glitches)
        self.set_current_glitch0 = dict(self.reader.current_glitches)
        self.set_summaries = []                                              # one text line per finished set
        self.cycle_log = []
        self.t0 = time.monotonic()
        os.makedirs(args.log_dir, exist_ok=True)
        self.p_raw = os.path.join(args.log_dir, f"autoen_raw_{stamp}.csv")
        self.p_sets = os.path.join(args.log_dir, f"autoen_sets_{stamp}.csv")
        self.p_cyc = os.path.join(args.log_dir, f"autoen_cycles_{stamp}.csv")
        self.p_thr = os.path.join(args.log_dir, f"autoen_thresholds_{stamp}.csv")
        head = ["time", "set", "cycle_in_set", "cycle_total", "phase"]
        for d in DEVICES:
            head += [f"{d}_{m}" for m in METRICS]
        self.raw_f = open(self.p_raw, "w", newline="", encoding="utf-8")
        self.raw_w = csv.writer(self.raw_f)
        self.raw_w.writerow(head)
        with open(self.p_sets, "w", newline="", encoding="utf-8") as f:
            # current_glitches is a NEW column (appended last, so nothing reading the older columns by
            # position breaks): single-sample current spikes the Reader held back pending a 2nd confirming
            # reading, per device, for this set -- see CURRENT_JUMP_MA above for why this exists.
            csv.writer(f).writerow(["set", "start", "end", "device", "metric", "n", "min", "avg", "max",
                                    "temp_glitches", "current_glitches"])
        with open(self.p_cyc, "w", newline="", encoding="utf-8") as f:
            # j6_carry_cur_max_ma / j6_carry_pos_delta_deg / grip_preload_used / grip_torque_limit_used /
            # grip_contact_deg are NEW columns (feature A/D monitoring), appended after the original ones so
            # anything reading this file by column name is unaffected; anything reading by fixed position
            # still gets the old columns first. grip_contact_deg is the REAL measured contact position (the
            # Mega's G,CLOSED report) -- use it, not back-math from aggregate position stats, to tune
            # --grip-fast-to-pos: it must stay above (numerically higher than) this value with margin.
            csv.writer(f).writerow(["set", "cycle_in_set", "cycle_total", "start", "seconds", "result", "drop", "travel_counts",
                                    "feed_s", "transport_s", "grip_s", "carry_s", "notes",
                                    "j6_carry_cur_max_ma", "j6_carry_pos_delta_deg",
                                    "grip_preload_used", "grip_torque_limit_used", "grip_contact_deg",
                                    # NEW (verification / recovery): IR state when GRIP started (1 = block there), seconds the
                                    # stall-crawl took (C,6 -> G,CLOSED), seconds from the cycle start to X,CONV (the belt gate),
                                    # and what the recovery after a failed cycle did
                                    "ir_at_grip", "crawl_s", "conv_start_s", "recovery", "queue", "gate_wait_s"])
        self.set_start = datetime.now().strftime("%H:%M:%S")

    @property
    def phase(self):
        return self._phase

    @phase.setter
    def phase(self, value):
        """Every phase change is also written to the TX log, so commands can be lined up with the arm's motion."""
        if value != self._phase:
            self.link.note(f"## cycle {self.cycle_total} phase {value}")
            now = time.monotonic()
            self.phase_times[self._phase] = self.phase_times.get(self._phase, 0.0) + now - self._phase_t0
            self._phase_t0 = now
        self._phase = value

    # ---------------------------------------------------------------- sampler (own thread)
    def sampler(self):
        while not self.stop_evt.is_set() or self.status == "stopping":
            t = time.monotonic()
            period = 1.0 / self.args.hz
            try:
                self._sample()
            except Exception:                               # noqa: BLE001 - one bad sample must not stop logging
                pass
            if self.status in ("finished", "stopped", "error"):
                break
            time.sleep(max(0.0, period - (time.monotonic() - t)))

    def _sample(self):
        vals = self.reader.read()
        with self.lock:
            self.live = vals                                # the page always shows live values ...
            if self.status not in ("preparing", "running"):
                return                                      # ... but only an active run is recorded and counted
            row = [datetime.now().isoformat(timespec="milliseconds"), self.set_no, self.cycle_in_set,
                   self.cycle_total, self.phase]
            for d in DEVICES:
                for m in METRICS:
                    v = vals[d][m]
                    row.append("" if v is None else round(v, 3))
                    if v is not None:
                        self.all_vals[d][m].append(v)
                        self.set_vals[d][m].append(v)
            self.raw_w.writerow(row)
            self._watch_belt_ina(vals)
            # feature D monitoring: while the arm is carrying the block (any CARRY_* phase), track J6's
            # current/position range for this one cycle -- a current climb or a position jump here is
            # exactly what a too-weak hold (slip) or a too-strong one (overheating) would look like.
            if not self.phase.startswith("CARRY"):
                self._carry_t0 = None                       # not carrying: the next carry starts a fresh settle timer
            elif getattr(self, "_carry_t0", None) is None:
                self._carry_t0 = time.monotonic()           # first sample of this carry
            # The J6 telemetry (~10 Hz) lags the gripper by a few samples, so the first CARRY_SETTLE_S still shows the
            # fingers closing / the old open position -- counting that as "slip" flagged clean grips GRIP_SUSPECT.
            if self.phase.startswith("CARRY") and time.monotonic() - self._carry_t0 >= CARRY_SETTLE_S:
                cur, pos = vals["J6"]["current"], vals["J6"]["position"]
                if cur is not None:
                    c = self.j6_carry
                    c["cur_min"] = cur if c["cur_min"] is None else min(c["cur_min"], cur)
                    c["cur_max"] = cur if c["cur_max"] is None else max(c["cur_max"], cur)
                if pos is not None:
                    c = self.j6_carry
                    c["pos_min"] = pos if c["pos_min"] is None else min(c["pos_min"], pos)
                    c["pos_max"] = pos if c["pos_max"] is None else max(c["pos_max"], pos)

    # ---------------------------------------------------------------- arm helpers
    def drive(self, targets, speed, timeout, label, belt_stop_at=None, acc=None):
        """Command {joint: ticks}; wait until all are within tolerance. Re-sends targets that have not arrived
        (the link drops a few % of lines). belt_stop_at: monotonic time at which to brake the belt meanwhile.
        acc: servo acceleration for this move only (defaults to --acc). Added for feature A's fast pre-close
        move: a short, one-shot P move is ACCELERATION-bound, not speed-bound (measured: 170 ticks at the
        default acc=8 took 0.86s -- matches the triangular-profile formula t=2*sqrt(distance/acc) almost
        exactly, and raising --grip-fast-speed alone cannot fix that). A higher acc here only affects this
        one move; every other P write in the file is unchanged (acc=None -> self.args.acc, same as before)."""
        acc = self.args.acc if acc is None else acc
        for sid, ticks in targets.items():
            self.link.write(f"P,{sid},{ticks},{speed},{acc}")
        end, last_resend, blind = time.monotonic() + timeout, time.monotonic(), None
        still = {}                                          # joint -> since when it sits still, short of the tolerance
        settled = {}                                        # joint -> error (ticks) accepted as "arrived"
        while True:
            if self.stop_evt.is_set():
                raise InterruptedError("stopped")
            if list(targets) == [6]:
                self.hold_tick()                            # the gripper moves: keep J1-5 where they are
            if belt_stop_at is not None and time.monotonic() >= belt_stop_at:
                self.link.belt_cmd("BRAKE")
                belt_stop_at = None
            pos = {sid: self.link.servo_pos(sid) for sid in targets}
            if any(p is None for p in pos.values()):
                blind = blind or time.monotonic()
                if time.monotonic() - blind > 2.0:
                    raise RuntimeError("servo feedback lost")
            else:
                blind = None
                tol = self.args.grip_tol if list(targets) == [6] else self.args.pose_tol
                now = time.monotonic()
                for sid in targets:                         # a joint that stops just short of the window (load, friction)
                    err = abs(pos[sid] - targets[sid])
                    if err > tol and self.args.settle_tol and err <= self.args.settle_tol \
                            and abs(self.link.servo_speed(sid)) <= 3:
                        still.setdefault(sid, now)
                        if now - still[sid] >= 1.5:
                            settled[sid] = pos[sid] - targets[sid]
                    else:
                        still.pop(sid, None)
                        settled.pop(sid, None)
                if all(abs(pos[s] - targets[s]) <= tol or s in settled for s in targets) and belt_stop_at is None:
                    if settled:
                        self.cycle_notes.append(f"settled {label}: " + ", ".join(f"J{k} {v:+d}t" for k, v in settled.items()))
                    break
            if time.monotonic() - last_resend >= 1.0:
                last_resend = time.monotonic()
                for sid, ticks in targets.items():
                    if pos[sid] is None or abs(pos[sid] - ticks) > self.args.pose_tol:
                        self.link.write(f"P,{sid},{ticks},{speed},{acc}")
            if time.monotonic() > end:
                raise TimeoutError(f"arm did not finish '{label}' within {timeout:.0f}s "
                                   f"(error ticks: { {s: (None if pos[s] is None else pos[s] - targets[s]) for s in targets} })")
            time.sleep(0.02)
        if list(targets) != [6]:
            for sid in targets:
                self.link.write(f"H,{sid}")                # hold where we stopped, like the dashboard does
            self.hold = {sid: (pos[sid] if sid in settled else targets[sid]) for sid in targets}   # pose to keep
            self.exc_open.clear()

    def pose(self, name, joints=range(1, 6)):
        return {sid: int(self.poses[name][str(sid)]) for sid in joints}

    def check_belt(self):
        b = self.link.belt
        if b and b["fault"] != 0:
            raise RuntimeError(f"belt fault code {b['fault']} (1 watchdog, 2 overtemp, 3 temp-sensor, 4 stall)")

    def gripper_torque_on(self):
        """H,6 before every gripper move. STS3215 servos power up torque-off; the Q firmware reads that at boot as
        'resting' and then ignores every P / J / C to that joint until H (holding J1-5 sends H, the gripper never did:
        2026-10-27 the gripper ignored every command after a power cycle). H = torque on where it is: no jump."""
        self.link.write("H,6")

    def gripper(self, target, label):
        target = max(GRIPPER_MIN, min(GRIPPER_MAX, int(target)))
        self.gripper_torque_on()
        self.drive({6: target}, self.args.gripper_speed, 12.0, label)

    def hold_tick(self):
        """Supervisor, called while the arm should stand still (gripper moving, feeder pushing, belt running, dwell).
        If a joint has drifted more than --hold-tol ticks from the pose it should hold (the arm sagging under gravity
        after a power dip, for instance), log it and send ONE corrective P - at most once a second per joint."""
        tol = self.args.hold_tol
        if not tol or not self.hold:
            return
        now = time.monotonic()
        for sid, target in self.hold.items():
            pos = self.link.servo_pos(sid)
            if pos is None:
                continue
            err = pos - target
            if abs(err) <= tol:
                self.exc_open.pop(sid, None)
                continue
            if not self.exc_open.get(sid):                  # a new drift: count it once
                self.exc_open[sid] = True
                self.total_excursions += 1
                msg = f"DRIFT J{sid} {err:+d}t in phase {self.phase}"
                self.cycle_notes.append(msg)
                self.link.note("## " + msg)
            if now - self.exc_last.get(sid, 0) >= 1.0:
                self.exc_last[sid] = now
                self.link.write(f"P,{sid},{target},{max(90, min(STS_MAX_TICKS_S, int(round(BASE_SPEED * self.args.arm_speed))))},{self.args.acc}")

    def dwell(self, seconds):
        """Pause (interruptible by Stop) - the arm holds where it is, supervised."""
        end = time.monotonic() + seconds
        while time.monotonic() < end:
            if self.stop_evt.is_set():
                raise InterruptedError("stopped")
            self.hold_tick()
            time.sleep(0.05)

    # ---------------------------------------------------------------- verification, recovery, diagnostics
    def new_cycle_info(self):
        """Fresh per-cycle record (also resets the cycle clock and the helper-thread list of the pipelined cycle)."""
        self.cycle_t0 = time.monotonic()
        self.bg_threads = []
        return {"drop": "", "travel": "", "grip_contact_ticks": "",
                "ir_at_grip": "", "crawl_s": "", "conv_start_s": "", "recovery": "", "queue": "", "gate_wait_s": ""}

    def ir_present(self):
        """Is a block sitting at the IR right now?  True / False, or None when the belt telemetry is missing or old."""
        b, bt = self.link.belt, self.link.belt_t
        if b is None or time.monotonic() - bt > 1.5:
            return None
        return bool(b["ir"])

    def guard_block_at_ir(self):
        """Never close the gripper on air: GRIP may only start while the IR confirms a block is at the pick point.
        (Cycle 7 of the 200956 run gripped with nothing there after a belt FAULT, and was logged OK.)"""
        present = self.ir_present()
        if self.args.enable_verify:
            # The belt's X,T telemetry only comes ~10 times a second, so right after ARRIVED the last reading may still be
            # from BEFORE the block reached the IR: give it a moment to catch up before calling the IR empty.
            end = time.monotonic() + self.args.ir_confirm_s
            while present is False and time.monotonic() < end:
                time.sleep(0.05)
                present = self.ir_present()
        self.cycle_info["ir_at_grip"] = "" if present is None else int(present)
        if self.args.enable_verify and present is False:
            raise CycleError("NO_BLOCK_AT_IR", "no block at the IR when GRIP was due - not closing on air")

    def verify_grip(self, contact_ticks):
        """Right after G,CLOSED and BEFORE anything is carried: did the fingers stop on a block?  The firmware reports CLOSED
        also when it merely ran out of crawl travel (nothing in the gripper), so look at WHERE it stopped: clean grips in the
        200956 run stopped at 181.8-182.0 deg; the three bad ones at 165-172 deg.  Outside the window = GRIP_MISS, and the
        caller's recovery opens the gripper again (the block is still at the IR, so the next cycle can retry it)."""
        a = self.args
        if not a.enable_verify or not isinstance(contact_ticks, (int, float)):
            return
        deg = contact_ticks * 360.0 / STEPS_PER_REV
        if not (a.grip_contact_min_deg <= deg <= a.grip_contact_max_deg):
            raise CycleError("GRIP_MISS", f"gripper stopped at {deg:.1f} deg, outside the block window "
                                          f"{a.grip_contact_min_deg:g}-{a.grip_contact_max_deg:g} deg - no block caught")

    def grade_grip(self, result, notes):
        """After a cycle that otherwise went fine: was the block really held while it was carried?  A second line of defence
        (the contact window above is the first).  This one cannot stop the carry -- opening the gripper mid-air would drop a
        block that may well be held -- so it only re-labels the cycle GRIP_SUSPECT instead of OK."""
        a = self.args
        if not a.enable_verify or result != "OK":
            return result, notes
        c, why = self.j6_carry, []
        if c["cur_max"] is not None and c["cur_max"] < a.grip_carry_min_ma:
            why.append(f"J6 current while carrying peaked at {c['cur_max']:.0f} mA (< {a.grip_carry_min_ma:g})")
        if c["pos_min"] is not None and c["pos_max"] - c["pos_min"] > a.grip_slip_max_deg:
            why.append(f"J6 moved {c['pos_max'] - c['pos_min']:.1f} deg while carrying (> {a.grip_slip_max_deg:g})")
        if c["cur_max"] is None and c["pos_min"] is None:
            # no J6 sample landed in the carry window (carry shorter than the settle time): the check could not run -- say so
            # in the notes instead of silently passing the cycle as verified
            self.cycle_notes.append("grip carry check had no J6 samples (carry shorter than CARRY_SETTLE_S)")
        if why:
            self.cycle_notes.append("GRIP_SUSPECT: " + "; ".join(why))
            return "GRIP_SUSPECT", notes
        return result, notes

    def _watch_belt_ina(self, vals):
        """The belt INA260 (D20/D21, 0x40) answers 'nan' when it cannot be read; the 200956 run had NO belt current at all and
        nothing said so.  Warn once, loudly, when the belt telemetry is alive but its current has been missing for ~10 s."""
        b, alive = vals.get("Belt", {}), self.link.belt is not None and time.monotonic() - self.link.belt_t < 2.0
        if alive and b.get("current") is None:
            self.belt_ina_bad += 1
        else:
            self.belt_ina_bad = 0
        if self.belt_ina_bad == max(10, int(10 * self.args.hz)) and not any("INA260" in w for w in self.warnings):
            msg = ("belt INA260 (D20/D21, addr 0x40) has returned nan for 10 s: belt current/power are NOT being recorded "
                   "- check its VCC/GND/SDA/SCL wires and send X,VER to see the diagnostic switches")
            self.warnings.append(msg)
            self.link.note("## WARNING " + msg)
            print("WARNING:", msg)

    def stop_background(self):
        """Stop the pipelined cycle's helper threads (next block's FEED wait / belt wait) and wait for them.  They share the
        events queue: left running after a failure they would swallow the ARRIVED of the recovery run, or send a late BRAKE."""
        self.bg_abort.set()
        for th in self.bg_threads:
            th.join(self.args.feed_timeout + 1.0)
        self.bg_threads = []
        self.bg_abort.clear()

    def run_belt_to_ir(self, timeout):
        """CONV without feeding: True if a block reached the IR within `timeout` s, False if the belt carries nothing."""
        while not self.link.events.empty():
            self.link.events.get_nowait()
        self.link.belt_cmd(f"CONV,{self.args.rpm:.2f}")
        end = time.monotonic() + timeout
        while time.monotonic() < end:
            if self.stop_evt.is_set():
                raise InterruptedError("stopped")
            self.hold_tick()
            try:
                name, args = self.link.events.get(timeout=0.1)
            except queue.Empty:
                continue
            if name == "FAULT":
                raise CycleError("FAULT_" + str(args[0] if args else "?"), "belt FAULT during recovery")
            if name == "ARRIVED":
                return True
        self.link.belt_cmd("BRAKE")
        return False

    def recover(self, code):
        """After a FAILED pipelined cycle: put the whole cell back into the state the next cycle starts from, "arm open at
        Standby, a block waiting at the IR, belt braked".  Without it the next cycle grips whatever is under the gripper
        (it did, after the belt FAULT in the 200956 run) because the arm was left at Home and no block was at the IR.
          1. stop the helper threads, forget stale events
          2. open the gripper (a block that was still held may fall here: this is a failure path), Home, then Standby
          3. block already at the IR (e.g. GRIP_MISS: it was never picked)  -> done
             else run the belt WITHOUT feeding: a prefetched block may be on its way (FAULT stopped it half way) -> done
             else the belt is empty: FEED one and bring it to the IR (the same bootstrap the run starts with)
        The caller has already sent X,STOP (that clears a latched belt fault).  Any failure in here ends the run: carrying on
        blind is how air got gripped."""
        a = self.args
        self.phase = "RECOVER"
        self.stop_background()
        while not self.link.events.empty():
            self.link.events.get_nowait()
        speed = max(90, min(STS_MAX_TICKS_S, int(round(BASE_SPEED * a.arm_speed))))
        self.gripper(a.open_pos, "open (recovery)")
        self.drive(self.pose("right"), speed, a.move_timeout, "home (recovery)")
        self.drive(self.pose("up"), speed, a.move_timeout, "standby (recovery)")
        if self.ir_present():
            self.cycle_info["recovery"] = f"after {code}: block already at the IR"
        elif self.run_belt_to_ir(a.recover_conv_s):
            self.cycle_info["recovery"] = f"after {code}: belt brought the waiting block to the IR"
        else:
            self.feed_and_transport_to_ir(speed)
            self.cycle_info["recovery"] = f"after {code}: belt was empty, fed a new block"
        self.cycle_notes.append("recovery: " + self.cycle_info["recovery"])

    # ---------------------------------------------------------------- one cycle
    def apply_belt_settings(self, force=False):
        """Send the belt/feeder settings to the Mega when they changed (or at the start)."""
        a = self.args
        want = {"CPR": f"CPR,{a.cpr:g}", "TEMPMAX": f"TEMPMAX,{a.temp_max:g}", "OFFSET": f"OFFSET,{a.offset}",
                "FEEDCFG": f"FEEDCFG,{a.feeder_home},{a.feeder_push},{a.feeder_push_ms},{a.feeder_return_ms}",
                "PID": f"PID,{a.kp:g},{a.ki:g},{a.kd:g}",               # belt speed loop (firmware default 0.5 / 1.5 / 0 is for CPR 1320; x9 here)
                # feature B finding: the belt's own watchdog (X,WDT, firmware default 500 ms, never sent by
                # this script before now) tripped (FAULT_1) in 2/10 pipelined cycles even though the PC kept
                # sending X,HB on schedule -- CONV now runs the motor+encoder ISR at the same time as the
                # arm's busiest multi-joint moves (never overlapped in the serial cycle), and an occasional
                # slow Mega loop() iteration under that combined load can miss the HB processing deadline.
                # Raising this gives more slack. TRADE-OFF: if the PC genuinely hangs/crashes, the belt now
                # keeps running that much longer before the Mega self-stops it -- do not raise this further
                # than needed to clear the false positives.
                "WDT": f"WDT,{a.belt_wdt_ms}"}
        for key, cmd in want.items():
            if force or self.applied.get(key) != cmd:
                self.link.belt_cmd(cmd)
                self.applied[key] = cmd
        if force:
            self.link.belt_cmd("ZERO")

    def close_gripper(self):
        """Close on the block with the Mega's stall-crawl (C,6). G,CLOSED = block held, G,ERROR = nothing gripped.

        Feature A (--enable-a, optional): race the gripper down to --grip-fast-to-pos with a normal, FAST
        P move first (that move has no stall protection -- it just drives to a fixed target), then hand off
        to the firmware's stall-crawl for only the last, contact-sensitive part. This is the main GRIP-phase
        time saver: the slow ~44 deg/s crawl used to run the WHOLE way from the open position; now it only
        has to cover the gap between grip_fast_to_pos and the real contact point.
          TRADE-OFF 1: grip_fast_to_pos MUST stay above (less closed than) the real block height, or the fast
          move slams into the block at grip_fast_speed with no stall detection to catch it. The default
          (~200 deg) is only a starting point computed from the --open-pos measurements in the task notes --
          verify it against the real blocks before trusting it, and raise it (less fast-stage travel, more
          margin) if the blocks vary in height.
          TRADE-OFF 2: a short one-shot P move is ACCELERATION-bound, not speed-bound -- round 1 measured a
          170-tick fast move taking 0.86 s at the default --acc (matches the triangular-motion-profile math
          almost exactly), so raising --grip-fast-speed alone did nothing. --grip-fast-acc raises the
          acceleration used for JUST this move (every other P write keeps using --acc) to actually shorten
          it; a higher value means more jerk/vibration and a harder impact if it does hit something early --
          verify there is no overshoot/vibration before raising it further.

        Feature D (--enable-d, optional): send a lower hold preload / torque limit than the firmware's fixed
        150-tick squeeze, which is the code-confirmed cause of J6's current climbing during CARRY (the
        firmware keeps commanding a position still inside the block). Lower --grip-hold-preload = less
        current/heat but less margin against the block slipping while carrying -- verify on a real carry
        before lowering it further. --grip-hold-torque-limit is wired the same way but defaults to 1000
        (off/no cap): try it only after --grip-hold-preload is confirmed safe, since a torque cap that is too
        low can let the block slip even with the preload target unchanged.
        """
        a = self.args
        self.gripper_torque_on()
        while not self.link.gevents.empty():
            self.link.gevents.get_nowait()
        if a.grip_pos:
            return self.close_to_position()
        if a.enable_a:
            # Only useful if the fast target is actually more-closed than wherever the gripper sits right
            # now (open_pos) -- the stall-crawl cannot "open" to get there, so skip the fast stage otherwise.
            current = self.link.servo_pos(6)
            if current is None or a.grip_fast_to_pos < current:
                try:
                    self.drive({6: a.grip_fast_to_pos}, a.grip_fast_speed, a.grip_fast_timeout,
                               "fast close to pre-contact (feature A)", acc=a.grip_fast_acc)
                except TimeoutError:
                    # Not fatal: the stall-crawl below still starts from wherever the gripper got to and
                    # finishes the close normally, just slower than planned for this one cycle.
                    self.cycle_notes.append("feature-A fast move timed out, finishing with the normal stall-crawl")
        # feature D: a plain "C,6" keeps the firmware's original defaults (150-tick preload, no torque cap)
        # exactly; only send the extra fields when the feature is on, so disabling it is a true revert.
        cmd = f"C,6,{a.grip_hold_preload},{a.grip_hold_torque_limit}" if a.enable_d else "C,6"
        self.link.write(cmd)
        t_crawl = time.monotonic()                          # for the crawl_s column: how long C,6 -> G,CLOSED takes
        end = time.monotonic() + a.grip_timeout
        while time.monotonic() < end:
            if self.stop_evt.is_set():
                raise InterruptedError("stopped")
            self.hold_tick()
            try:
                state, pos, torque_readback = self.link.gevents.get(timeout=0.1)
            except queue.Empty:
                continue
            if state == "CLOSED":
                # feature D round 2: confirm the torque-limit write the Mega just read back actually
                # matches what we asked for -- if it does not, the write (or the readback itself) was
                # dropped on the lossy UART, which is the leading explanation for current not dropping.
                if a.enable_d and a.grip_hold_torque_limit < 1000:
                    if torque_readback == a.grip_hold_torque_limit:
                        self.cycle_notes.append(f"torque_limit confirmed={torque_readback}")
                    else:
                        self.cycle_notes.append(f"torque_limit NOT confirmed (asked {a.grip_hold_torque_limit}, "
                                                f"Mega read back {torque_readback})")
                self.cycle_info["crawl_s"] = round(time.monotonic() - t_crawl, 2)
                return pos
            if state == "ERROR":
                raise CycleError("GRIP_FAILED", f"gripper close not confirmed at {pos} ticks - nothing carried away")
        raise CycleError("GRIP_FAILED", f"no gripper stall confirmation within {a.grip_timeout:g} s")

    def close_to_position(self):
        """--grip-pos: close J6 to ONE taught position and stop there -- no stall-crawl, no squeeze past contact.

        The stall-crawl closes until the jaws cannot move any more (at full torque until it notices), which crunched
        the blocks and slipped J6 by ~4 deg on 2026-10-24. Here the gripper only goes to grip_pos (taught on a real block).
        Feature A's fast move still runs first when it is more open than grip_pos, then a slow move covers the rest.
        If J6 stops short (block wider than the taught one), it holds GRIP_POS_SHORT_SQUEEZE ticks past where it stopped
        instead of pushing on toward grip_pos. Returns the final J6 position (checked by verify_grip like a crawl stop)."""
        a = self.args
        target = max(GRIPPER_MIN, min(GRIPPER_MAX, int(a.grip_pos)))
        t0 = time.monotonic()
        current = self.link.servo_pos(6)
        if a.enable_a and target < a.grip_fast_to_pos and (current is None or a.grip_fast_to_pos < current):
            try:
                self.drive({6: a.grip_fast_to_pos}, a.grip_fast_speed, a.grip_fast_timeout,
                           "fast close to pre-contact (feature A)", acc=a.grip_fast_acc)
            except TimeoutError:
                self.cycle_notes.append("feature-A fast move timed out, finishing with the slow move to grip_pos")
        start = self.link.servo_pos(6)
        self.link.write(f"P,6,{target},{a.grip_pos_speed},{a.acc}")
        # J6 cannot be "stopped on a block" before it had time to get there: the position telemetry lags and the servo
        # ramps up, so a reading that has not changed yet only means it has not started (2026-10-25: judged after 0.44 s
        # -> held at 205 deg, GRIP_MISS). Judge only after the travel time, and resend if it never left its start.
        travel_s = (abs(start - target) / max(1, a.grip_pos_speed) if start is not None else 1.0) + 0.3
        t_cmd, resent = time.monotonic(), 0
        end, last, still, p = time.monotonic() + a.grip_timeout, None, None, None
        while True:
            if self.stop_evt.is_set():
                raise InterruptedError("stopped")
            self.hold_tick()
            p = self.link.servo_pos(6)
            now = time.monotonic()
            if p is not None:
                if abs(p - target) <= a.grip_tol and (abs(p - target) <= 3 or (last is not None and abs(p - last) <= 2)):
                    break                                   # arrived and settled: p is where the jaws really are
                if now - t_cmd < travel_s:
                    last, still = p, None
                elif start is not None and (p - start) * (1 if target > start else -1) < GRIP_POS_NOT_STARTED and resent < 2:
                    self.link.write(f"P,6,{target},{a.grip_pos_speed},{a.acc}")   # the command was lost: send it again
                    self.cycle_notes.append(f"grip_pos move did not start (J6 still at {p}): resent")
                    t_cmd, resent, last, still = now, resent + 1, p, None
                elif last is not None and abs(p - last) <= 2:     # not moving any more, short of grip_pos
                    still = still or now
                    if now - still >= GRIP_POS_STILL_S:
                        hold = max(target, p - GRIP_POS_SHORT_SQUEEZE)
                        self.link.write(f"P,6,{hold},{a.grip_pos_speed},{a.acc}")
                        self.cycle_notes.append(f"gripper stopped {p - target:+d}t short of grip_pos {target}: "
                                                f"holding at {hold} (block wider than taught)")
                        break
                else:
                    still = None
                last = p
            if now > end:
                raise CycleError("GRIP_FAILED", f"gripper did not reach grip_pos {target} within {a.grip_timeout:g} s (at {p})")
            time.sleep(0.05)
        self.cycle_info["crawl_s"] = round(time.monotonic() - t0, 2)
        return p

    def feed_and_transport_to_ir(self, speed):
        """FEED one block, then run the belt (arm driven to Standby on its own thread meanwhile) until the
        IR sees it. This is the ORIGINAL serial FEED+TRANSPORT pair, factored out so it can be reused both
        by the serial one_cycle() (every cycle, unchanged) and by feature B's pipelined cycle (ONLY once,
        as the bootstrap that gets the very first block to the IR before the overlapped loop can start)."""
        a = self.args
        # ---- FEED: one block onto the belt
        self.phase = "FEED"
        while not self.link.events.empty():
            self.link.events.get_nowait()
        self.link.belt_cmd("FEED")
        end = time.monotonic() + a.feed_timeout
        while time.monotonic() < end:                       # wait for FEED_DONE (or a FAULT)
            self.hold_tick()                                # the feeder is pushing: watch the arm
            try:
                name, args = self.link.events.get(timeout=0.2)
            except queue.Empty:
                continue
            if name == "FAULT":
                raise CycleError("FAULT_" + str(args[0] if args else "?"), "belt FAULT during FEED")
            if name == "FEED_DONE":
                break
        else:
            raise CycleError("TIMEOUT_FEED", f"no FEED_DONE within {a.feed_timeout:g} s")
        # ---- TRANSPORT: arm to Standby (own thread) while the belt runs until the IR sees the block
        self.phase = "TRANSPORT"
        err = []

        def standby():
            try:
                self.drive(self.pose("up"), speed, a.move_timeout, "up (standby)")
            except BaseException as e:                      # noqa: BLE001 - re-raised below
                err.append(e)
        th = threading.Thread(target=standby, daemon=True)
        th.start()
        tel = self.link.belt
        enc0 = tel["enc"] if tel else 0
        while not self.link.events.empty():
            self.link.events.get_nowait()
        arrived = None
        self.transport_abort.clear()
        try:
            self.link.belt_cmd(f"CONV,{a.rpm:.2f}")         # run until the IR; the Mega brakes and sends ARRIVED
            end = time.monotonic() + a.arrive_timeout
            while time.monotonic() < end:
                if self.stop_evt.is_set():
                    raise InterruptedError("stopped")
                if self.transport_abort.is_set():           # the feeder was empty: do not run the belt to the timeout
                    self.link.belt_cmd("BRAKE")
                    raise CycleError("NO_BLOCK", "transport aborted: no block on the camera after FEED")
                if not th.is_alive():
                    self.hold_tick()                        # arm waiting at Standby: supervised
                try:
                    name, args = self.link.events.get(timeout=0.1)
                except queue.Empty:
                    continue
                if name == "FAULT":
                    raise CycleError("FAULT_" + str(args[0] if args else "?"), "belt FAULT during TRANSPORT")
                if name == "ARRIVED":
                    arrived = args
                    break
            if arrived is None:
                try:
                    self.link.belt_cmd("BRAKE")
                except Exception:                           # noqa: BLE001
                    pass
                raise CycleError("TIMEOUT_TRANSPORT", f"block did not reach the IR within {a.arrive_timeout:g} s")
        finally:
            th.join(a.standby_timeout)
        if th.is_alive():
            raise CycleError("TIMEOUT_STANDBY", "arm did not reach Standby in time")
        if err:
            raise err[0]
        if arrived and arrived[0].lstrip("-").isdigit():
            self.cycle_info["travel"] = int(arrived[0]) - enc0
        self.check_belt()
        self.dwell(a.dwell_standby)

    def one_cycle(self):
        a = self.args
        self.phase_times, self._phase_t0 = {}, time.monotonic()
        self.cycle_info = self.new_cycle_info()
        self.j6_carry = {"cur_min": None, "cur_max": None, "pos_min": None, "pos_max": None}   # feature D monitoring, this cycle only
        speed = max(90, min(STS_MAX_TICKS_S, int(round(BASE_SPEED * a.arm_speed))))                       # free moves
        cspeed = min(CARRY_CAP_TICKS_S, max(90, min(STS_MAX_TICKS_S, int(round(BASE_SPEED * a.carry_speed)))))   # with the block
        self.apply_belt_settings()
        self.feed_and_transport_to_ir(speed)
        # ---- 3. GRIP the block (belt stays braked)
        self.phase = "GRIP"
        self.guard_block_at_ir()
        try:
            # feature A tuning: the Mega reports the exact position it detected the stall at (the real
            # contact point) on the G,CLOSED line -- log it directly instead of back-computing it from
            # aggregate position stats (which get confounded by --grip-hold-preload differing between runs).
            self.cycle_info["grip_contact_ticks"] = self.close_gripper()
            self.verify_grip(self.cycle_info["grip_contact_ticks"])     # stopped outside the block window = nothing caught
        except CycleError:
            self.phase = "RECOVER"                          # nothing gripped: open and go Home, then log the failure
            try:
                self.gripper(a.open_pos, "open after failed grip")
                self.drive(self.pose("right"), speed, a.move_timeout, "home after failed grip")
            except Exception:                               # noqa: BLE001
                pass
            raise
        self.dwell(a.dwell_grip)
        # ---- 4. CARRY: Home first, then the drop pose (alternating)
        self.phase = "CARRY_HOME"
        self.drive(self.pose("right"), cspeed, a.move_timeout, "home with block")
        if a.drop_mode == "alternate":
            first_is_left = a.first_drop == "left"
            drop = "left" if (self.cycle_total % 2 == 1) == first_is_left else "down"
        else:
            drop = a.drop_mode
        self.cycle_info["drop"] = drop
        self.phase = "CARRY_" + drop.upper()
        self.drive(self.pose(drop), cspeed, a.move_timeout, f"drop pose '{drop}'")
        self.dwell(a.dwell_drop)
        # ---- 5. RELEASE
        self.phase = "RELEASE"
        self.gripper(a.open_pos, f"open at '{drop}'")
        # ---- 6. HOME
        self.phase = "HOME"
        self.drive(self.pose("right"), speed, a.move_timeout, "home")
        self.dwell(a.dwell_home)
        # ---- 7. CLEAR: the block must be gone from the IR before the next feed
        self.phase = "CLEAR"
        end = time.monotonic() + a.clear_timeout
        while time.monotonic() < end:
            self.hold_tick()
            b = self.link.belt
            if b is not None and not b["ir"]:
                self.phase = "IDLE"
                return
            time.sleep(0.05)
        self.phase = "IDLE"
        raise CycleError("BLOCK_STILL_AT_IR", "pick may have failed")

    def one_cycle_pipelined(self):
        """Feature B (--enable-b): overlap block n+1's FEED+CONV with block n's CARRY/RELEASE/HOME instead
        of doing the two fully serially (the baseline spends ~46% of every cycle with the arm just
        standing still waiting for TRANSPORT). The constraint from the task notes is unchanged: the belt
        must stay braked for the WHOLE of GRIP (the block must sit still directly under the gripper).

        Sequence for cycle n (a block is already waiting at the IR when this is called):
          1. GRIP block n (features A/D apply exactly as in the serial cycle).
          2. FEED block n+1 onto the belt -- this only pushes the magazine blade, it never moves the belt
             itself, so it is safe to do immediately, in parallel with the grip crawl above, while the belt
             stays braked.
          3. CARRY_HOME: drive the arm (with block n) to the home pose. This drive() call does not return
             until the arm has ACTUALLY reached that pose -- that is the gate the task notes ask for
             ("confirm the arm is clear of the belt, not a guess from a timer"), because the home pose is,
             by construction, clear of the belt area.
          4. Only once that gate has passed: start CONV for block n+1 on a background thread, while the
             main thread continues CARRY_LEFT/DOWN -> RELEASE -> HOME -> Standby exactly as the serial
             cycle's phases of the same name.
          5. The cycle finishes once BOTH are done: the background thread reports ARRIVED (joined) AND the
             arm is confirmed back at Standby.

        NOTE on the logged phase columns: transport_s will read ~0 for pipelined cycles -- there is no
        longer a single blocking "TRANSPORT" phase; the belt's travel time is now hidden inside whichever
        of CARRY_LEFT/CARRY_DOWN/RELEASE/HOME/STANDBY the arm happens to be in when CONV finishes. This is
        expected, not a bug.

        NOTE on the empty-magazine case: if block n+1's FEED or CONV fails (e.g. the magazine just ran
        out), THIS cycle (n) is reported as failed even though block n itself was picked and placed
        successfully -- the failure is really "could not prepare the NEXT block", attributed to the
        current cycle because that is where the prefetch happened. Same total fail count as the serial
        cycle's "ran out of blocks" case, just attributed one cycle earlier.
        """
        a = self.args
        self.phase_times, self._phase_t0 = {}, time.monotonic()
        self.cycle_info = self.new_cycle_info()
        self.j6_carry = {"cur_min": None, "cur_max": None, "pos_min": None, "pos_max": None}
        speed = max(90, min(STS_MAX_TICKS_S, int(round(BASE_SPEED * a.arm_speed))))
        cspeed = min(CARRY_CAP_TICKS_S, max(90, min(STS_MAX_TICKS_S, int(round(BASE_SPEED * a.carry_speed)))))
        self.apply_belt_settings()

        # ---- 1. GRIP the block already waiting at the IR (belt stays braked throughout)
        self.phase = "GRIP"
        self.guard_block_at_ir()                            # the IR must really show a block (NO_BLOCK_AT_IR otherwise)
        try:
            self.cycle_info["grip_contact_ticks"] = self.close_gripper()
            self.verify_grip(self.cycle_info["grip_contact_ticks"])     # stopped outside the block window = nothing caught
        except CycleError:
            self.phase = "RECOVER"
            try:
                self.gripper(a.open_pos, "open after failed grip")
                self.drive(self.pose("right"), speed, a.move_timeout, "home after failed grip")
            except Exception:                               # noqa: BLE001
                pass
            raise
        self.dwell(a.dwell_grip)

        # ---- 2. FEED block n+1 now: only pushes the magazine blade, never moves the belt, so this is
        # safe regardless of where the arm is. Runs on a background thread so it does not block CARRY_HOME
        # below; joined before step 4 needs to know it actually finished.
        self.phase = "FEED"
        while not self.link.events.empty():
            self.link.events.get_nowait()
        self.link.belt_cmd("FEED")
        feed_result = {}

        def wait_feed():
            end = time.monotonic() + a.feed_timeout
            while time.monotonic() < end:
                if self.stop_evt.is_set() or self.bg_abort.is_set():
                    feed_result["err"] = InterruptedError("stopped")
                    return
                try:
                    name, fargs = self.link.events.get(timeout=0.2)
                except queue.Empty:
                    continue
                if name == "FAULT":
                    feed_result["err"] = CycleError("FAULT_" + str(fargs[0] if fargs else "?"), "belt FAULT during FEED")
                    return
                if name == "FEED_DONE":
                    feed_result["done"] = True
                    return
            feed_result["err"] = CycleError("TIMEOUT_FEED", f"no FEED_DONE within {a.feed_timeout:g} s")
        feed_th = threading.Thread(target=wait_feed, daemon=True)
        feed_th.start()
        self.bg_threads.append(feed_th)                     # recover() joins it

        # ---- 3. CARRY_HOME: the GATE. This drive() call blocks until the arm has actually reached the
        # home pose -- only then is it proven clear of the belt.
        self.phase = "CARRY_HOME"
        self.drive(self.pose("right"), cspeed, a.move_timeout, "home with block")

        # Supervised wait (not a blind join()): CARRY_HOME already finished moving joints 1-5, so if this
        # wait runs long the arm is sitting idle and needs the same drift watch dwell()/drive() give it
        # elsewhere -- a plain join() here would skip that entirely.
        feed_end = time.monotonic() + a.feed_timeout + 1.0
        while feed_th.is_alive() and time.monotonic() < feed_end:
            if self.stop_evt.is_set():
                raise InterruptedError("stopped")
            self.hold_tick()
            time.sleep(0.05)
        if feed_th.is_alive():
            raise CycleError("TIMEOUT_FEED", "feeder thread did not finish")
        if "err" in feed_result:
            raise feed_result["err"]

        # ---- 4. Hand off: arm confirmed clear, so start CONV for block n+1 on a background thread while
        # the main thread keeps driving the arm through the rest of the cycle in parallel.
        while not self.link.events.empty():
            self.link.events.get_nowait()
        tel = self.link.belt
        enc0 = tel["enc"] if tel else 0
        conv_result = {}

        # ---- feature C (--enable-c): belt queue.  With ONE block always travelling alone the belt has to run its whole
        # length every cycle.  If a SECOND block is dropped on the belt while the first is still half way, the two stop
        # ~half a belt apart (the IR stops the lead block, the one behind stops with it) and from then on every CONV only
        # has to move the queued block HALF the belt (the new FEED each cycle lands at the belt start, then moves the same
        # distance, so the spacing keeps itself at about half).  Needs the full travel time, measured on an unqueued cycle.
        prime = bool(a.enable_c and self.q_extra == 0 and self.q_tfull is not None)
        qstat = {"fed_at": None, "t0": None}
        self.cycle_info["queue"] = "prime" if prime else ("run" if (a.enable_c and self.q_extra == 1) else
                                                         ("measure" if (a.enable_c and self.q_extra == 0) else
                                                          ("unknown" if a.enable_c else "")))

        def wait_arrived():
            try:
                self.cycle_info["conv_start_s"] = round(time.monotonic() - self.cycle_t0, 2)   # the belt gate, for the CSV
                # ---- arrival guard (--arrival-guard): the arm's last move is DOWN into the pick pose ("up" = Standby, fingers open
                # around the IR spot).  A block that reaches the IR before that move is finished gets hit by the fingers
                # (the 210804/213339 logs: ARRIVED up to 0.5 s BEFORE the STANDBY move even began in 3 of the C-on cycles,
                # and only 0.6-0.7 s after it began in 2 of the C-off ones).  So hold the belt back until the block can only
                # arrive after the arm is parked + a margin, from what the last cycles measured: slowest arm tail (CONV gate ->
                # Standby reached) vs fastest belt travel.  Costs nothing when the belt is slower than the arm anyway.
                qstat["g0"] = time.monotonic()
                gate_wait = 0.0
                if a.arrival_guard and self.tail_hist and self.trav_hist:
                    trav = min(self.trav_hist)
                    if a.enable_c and self.q_extra == 1 and self.q_tfull:
                        trav = min(trav, self.q_tfull * (1.0 - a.queue_split) * 0.8)    # queued block: ~half the belt left
                    gate_wait = max(0.0, max(self.tail_hist) - trav + a.arrival_margin_s)
                    gate_wait = min(gate_wait, 8.0)           # never sit on the belt for more than this
                self.cycle_info["gate_wait_s"] = round(gate_wait, 2)
                while gate_wait > 0 and time.monotonic() - qstat["g0"] < gate_wait:
                    if self.stop_evt.is_set() or self.bg_abort.is_set():
                        conv_result["err"] = InterruptedError("stopped")
                        return
                    time.sleep(0.05)
                qstat["t0"] = time.monotonic()
                self.link.belt_cmd(f"CONV,{a.rpm:.2f}")
            except Exception as e:                          # noqa: BLE001
                conv_result["err"] = e
                return
            end = time.monotonic() + a.arrive_timeout
            while time.monotonic() < end:
                if self.stop_evt.is_set() or self.bg_abort.is_set():
                    conv_result["err"] = InterruptedError("stopped")      # abort = recover() is taking over: no late BRAKE
                    return
                if prime and qstat["fed_at"] is None and time.monotonic() - qstat["t0"] >= self.q_tfull * a.queue_split:
                    try:
                        self.link.belt_cmd("FEED")          # feature C: 2nd block onto the MOVING belt -> ends up ~half a belt
                        qstat["fed_at"] = time.monotonic()  # behind the lead block (its FEED_DONE is ignored by this loop)
                    except Exception as e:                  # noqa: BLE001
                        conv_result["err"] = e
                        return
                try:
                    name, cargs = self.link.events.get(timeout=0.1)
                except queue.Empty:
                    continue
                if name == "FAULT":
                    conv_result["err"] = CycleError("FAULT_" + str(cargs[0] if cargs else "?"), "belt FAULT during pipelined CONV")
                    return
                if name == "ARRIVED":
                    conv_result["arrived"] = cargs
                    conv_result["t_s"] = time.monotonic() - qstat["t0"]      # belt travel time of this CONV (feature C)
                    return
            try:
                self.link.belt_cmd("BRAKE")
            except Exception:                               # noqa: BLE001
                pass
            conv_result["err"] = CycleError("TIMEOUT_TRANSPORT", f"block n+1 did not reach the IR within {a.arrive_timeout:g} s")
        conv_th = threading.Thread(target=wait_arrived, daemon=True)
        conv_th.start()
        self.bg_threads.append(conv_th)                     # recover() joins it

        # ---- CARRY_LEFT/DOWN -> RELEASE -> HOME -> STANDBY: same phases as the serial cycle, running on
        # the main thread while conv_th runs the belt in the background. hold_tick() (called inside drive()
        # and dwell()) only ever compares joint 1-5 positions to self.hold -- it has no belt awareness, so
        # it needs no change to behave correctly with the belt now running concurrently.
        if a.drop_mode == "alternate":
            first_is_left = a.first_drop == "left"
            drop = "left" if (self.cycle_total % 2 == 1) == first_is_left else "down"
        else:
            drop = a.drop_mode
        self.cycle_info["drop"] = drop
        self.phase = "CARRY_" + drop.upper()
        self.drive(self.pose(drop), cspeed, a.move_timeout, f"drop pose '{drop}'")
        self.dwell(a.dwell_drop)
        self.phase = "RELEASE"
        self.gripper(a.open_pos, f"open at '{drop}'")
        self.phase = "HOME"
        self.drive(self.pose("right"), speed, a.move_timeout, "home")
        self.dwell(a.dwell_home)
        self.phase = "STANDBY"
        self.drive(self.pose("up"), speed, a.move_timeout, "up (standby)")

        qstat["arm_done"] = time.monotonic()                # arrival guard: the arm is parked now
        # ---- 5. The cycle only finishes once BOTH are true: arm at Standby (just confirmed above) and
        # the belt thread reports ARRIVED for block n+1. Supervised wait, same reasoning as the FEED wait
        # above -- the arm is idle at Standby for however long this takes, same as the serial cycle's
        # TRANSPORT wait (which also calls hold_tick() while idle, not a blind join()).
        conv_end = time.monotonic() + a.arrive_timeout + 1.0
        while conv_th.is_alive() and time.monotonic() < conv_end:
            if self.stop_evt.is_set():
                raise InterruptedError("stopped")
            self.hold_tick()
            time.sleep(0.05)
        if conv_th.is_alive():
            raise CycleError("TIMEOUT_TRANSPORT", "belt thread did not finish")
        if "err" in conv_result:
            raise conv_result["err"]
        arrived = conv_result.get("arrived")
        if "t_s" in conv_result and qstat.get("arm_done") and qstat.get("g0"):    # arrival guard bookkeeping
            self.tail_hist = (self.tail_hist + [qstat["arm_done"] - qstat["g0"]])[-3:]
            self.trav_hist = (self.trav_hist + [conv_result["t_s"]])[-3:]
        if a.enable_c and self.q_extra is not None:             # feature C bookkeeping for the NEXT cycle
            if prime and qstat["fed_at"] is not None and "t_s" in conv_result and \
                    qstat["fed_at"] - qstat["t0"] < conv_result["t_s"]:
                self.q_extra = 1                                # the queued block really went onto the belt before ARRIVED
            elif self.q_extra == 0 and not prime and "t_s" in conv_result:
                self.q_tfull = conv_result["t_s"]               # a lone block's full travel: what priming times itself from
        if a.enable_c and self.q_tfull and not prime and "t_s" in conv_result:
            # Learn the queue state back from what the belt really did (222658 log: after the first GRIP_MISS the state stayed
            # "unknown" for 80 cycles although the queued block was still there and every CONV was still ~half a belt).
            # Travel well under the full-belt time = a second block was waiting; a full-length trip = the belt was empty.
            ratio = conv_result["t_s"] / self.q_tfull
            if ratio >= 0.9 and self.q_extra != 0:
                self.q_extra = 0                                # empty belt: the next cycle may prime again
            elif ratio <= 0.75 and self.q_extra is None:
                self.q_extra = 1                                # queue is back
        if arrived and arrived[0].lstrip("-").isdigit():
            self.cycle_info["travel"] = int(arrived[0]) - enc0
        self.check_belt()
        self.phase = "IDLE"

    def _sequence(self, steps, label):
        """Drive the steps of a rest / wake sequence one after the other (each step moves only the joints it lists)."""
        cfg = self.args.pose_cfg
        try:
            for step in steps:
                speed = int(step.get("speed", cfg.get("rest_speed", 200)))
                self.drive({int(k): int(v) for k, v in step["joints"].items()}, speed, self.args.move_timeout,
                           f"{label}: {step['name']}")
        except Exception:
            # a step that failed (blocked, feedback lost) must NOT be retried later by the drift supervisor:
            # freeze every joint where it is and supervise nothing until the operator sends wake / Stop
            self.hold = {}
            self.exc_open.clear()
            for sid in range(1, 7):
                self.link.write(f"H,{sid}")
            self.link.note(f"## {label} failed: all joints hold where they are, drift supervisor off")
            raise

    def _torque(self, joints, on):
        """Q,<id>,1|0 for every joint and wait for the Mega's reply. Returns the joints that did NOT confirm."""
        with self.link.slock:
            for sid in joints:
                self.link.torque.pop(sid, None)
        missing = list(joints)
        for _ in range(3):                                  # the link drops a few % of lines: ask again
            for sid in missing:
                self.link.write(f"Q,{sid},{1 if on else 0}")
            end = time.monotonic() + 0.6
            while time.monotonic() < end:
                with self.link.slock:
                    missing = [s for s in joints if self.link.torque.get(s, (None,))[0] != (1 if on else 0)]
                if not missing:
                    return []
                time.sleep(0.02)
        return missing

    def go_rest(self, torque_off=False):
        """rest task: lift -> align -> coil -> lower onto the cradle (config/poses.json), optionally torque off once still.
        Returns the move time in seconds."""
        cfg, t0 = self.args.pose_cfg, time.monotonic()
        self.phase = "REST"
        self.rest_state = "resting"                         # from the first step on: no hold_pose / resume until wake
        self._sequence(cfg["rest_sequence"], "rest")
        self.hold = self.pose("rest")                       # supervise the whole rest pose (J1-5), not just the last step
        self.exc_open.clear()
        move_s = time.monotonic() - t0
        if torque_off:
            settle = time.monotonic() + float(cfg.get("torque_off_settle_s", 1.0))
            while time.monotonic() < settle:                # let it sit on the cradle before letting go
                self.hold_tick()
                time.sleep(0.05)
            joints = [int(j) for j in cfg.get("torque_off_joints", [1, 2, 3, 4, 5])]
            bad = self._torque(joints, on=False)
            if bad:
                self._torque(joints, on=True)               # all or nothing: never leave half the arm limp
                raise RuntimeError(f"torque off not confirmed for J{bad}: torque left ON")
            self.hold = {}                                  # nothing to supervise: the cradle carries the arm
            self.rest_state = "resting_torque_off"
            self.link.note("## rest: torque OFF " + ",".join(f"J{j}" for j in joints))
        return round(move_s, 2)

    def wake(self):
        """wake task: torque back on at the PRESENT positions (no jump), then lift -> uncoil -> home. Returns seconds."""
        cfg, t0 = self.args.pose_cfg, time.monotonic()
        self.phase = "WAKE"
        if self.rest_state == "resting_torque_off":
            joints = [int(j) for j in cfg.get("torque_off_joints", [1, 2, 3, 4, 5])]
            bad = self._torque(joints, on=True)
            if bad:
                raise RuntimeError(f"torque on not confirmed for J{bad}: the arm stays on the cradle")
            self.rest_state = "resting"
            self.link.note("## wake: torque ON " + ",".join(f"J{j}" for j in joints))
        self._sequence(cfg["wake_sequence"], "wake")
        speed = max(90, min(STS_MAX_TICKS_S, int(round(BASE_SPEED * self.args.arm_speed))))
        self.drive(self.pose("right"), speed, self.args.move_timeout, "wake: home")
        self.rest_state = "awake"
        return round(time.monotonic() - t0, 2)

    def wait_if_paused(self):
        """Pause button: hold between cycles (arm supervised) until Resume or Stop. A resting arm stays paused until wake."""
        if not self.pause_evt.is_set() and self.rest_state == "awake":
            return
        prev, self.status = self.status, "paused"
        while self.pause_evt.is_set() or self.rest_state != "awake":
            if self.stop_evt.is_set():
                raise InterruptedError("stopped")
            try:
                job = self.tasks.get_nowait()
            except queue.Empty:
                job = None
            if job is not None:
                self.run_task(job)
                continue
            self.hold_tick()
            time.sleep(0.1)
        self.status = prev

    def abort_transport(self):
        """POST /api/abort_transport (orchestrator): end the serial TRANSPORT now -> belt BRAKE, cycle result NO_BLOCK.
        Only while that phase runs; the pipelined cycle (enable_b) has no such exit."""
        if self.args.enable_b:
            raise ValueError("abort_transport only works with enable_b = 0")
        if self.status != "running" or self.phase != "TRANSPORT":
            raise ValueError(f"no transport to abort (status {self.status}, phase {self.phase})")
        self.transport_abort.set()
        return {"aborting": True, "cycle": self.cycle_total}

    TASK_KINDS = ("belt_run", "hold_pose", "idle", "rest", "wake")

    def check_task(self, t):
        """Validate a /api/task body. Raises ValueError (-> HTTP 400). Only accepted while paused with nothing queued."""
        if self.status != "paused":
            raise ValueError(f"tasks only run while paused (status is {self.status})")
        if self.task is not None and self.task["status"] in ("queued", "running"):
            raise ValueError(f"task {self.task['id']} is still {self.task['status']}")
        kind = t.get("kind", t.get("task"))                 # {"task": "rest"} is accepted as well as {"kind": "rest"}
        if kind not in self.TASK_KINDS:
            raise ValueError(f"kind must be one of {self.TASK_KINDS}")
        cfg = getattr(self.args, "pose_cfg", None)
        if kind in ("rest", "wake") and not cfg:
            raise ValueError(f"no rest pose: {getattr(self.args, 'pose_config', '') or '--pose-config'} was not loaded")
        if kind == "rest" and self.rest_state != "awake":
            raise ValueError(f"the arm is already resting ({self.rest_state})")
        if kind == "wake" and self.rest_state == "awake":
            raise ValueError("the arm is not resting")
        if kind == "hold_pose" and self.rest_state != "awake":
            raise ValueError("the arm is resting: send the wake task first")
        clean = {"kind": kind, "seconds": float(t.get("seconds", 30.0)), "settle_s": float(t.get("settle_s", 3.0))}
        if not 1.0 <= clean["seconds"] <= 600.0:
            raise ValueError("seconds must be 1..600")
        if not 0.0 <= clean["settle_s"] < clean["seconds"]:
            raise ValueError("settle_s must be 0..seconds")
        if kind == "belt_run":
            lo, hi, _ = self.LIMITS["rpm"]
            clean["rpm"] = float(t.get("rpm", self.args.rpm))
            if not lo <= clean["rpm"] <= hi:
                raise ValueError(f"rpm must be {lo}..{hi}")
        if kind == "hold_pose":
            clean["pose"] = str(t.get("pose", "right"))
            if clean["pose"] == "rest":
                raise ValueError("use the rest task for the rest pose (it moves in a safe order)")
            if clean["pose"] not in self.poses:
                raise ValueError(f"pose must be one of {sorted(self.poses)}")
        if kind == "rest":
            clean["torque_off"] = bool(t.get("torque_off", False))
        return clean

    def submit_task(self, t):
        clean = self.check_task(t)
        self.task = {"id": (self.task["id"] + 1) if self.task else 1, "status": "queued", **clean,
                     "t_start": None, "t_end": None, "arrived": False, "error": None, "stats": None}
        self.tasks.put(self.task)
        return self.task

    def run_task(self, job):
        """Run one queued job on the run thread (called from wait_if_paused). belt_run: CONV at job rpm with no FEED, BRAKE at the
        end -- an empty belt never reaches ARRIVED, so a block on the belt ends the job early with arrived=True. hold_pose: drive
        J1-5 to the pose at arm_speed, then hold. idle: hold only. Belt rpm / mA / W and summed arm mA / W are sampled throughout;
        the stats skip the first settle_s seconds (belt spin-up)."""
        a = self.args
        job.update(status="running", t_start=time.time())
        self.phase = "TASK_" + job["kind"].upper()
        self.link.note(f"## task {job['id']} {job['kind']} " + json.dumps({k: job[k] for k in ("seconds", "rpm", "pose") if k in job}))
        belt, arm, last_ms, last_arm, final = [], [], None, 0.0, "error"
        try:
            if job["kind"] == "belt_run":
                while not self.link.events.empty():
                    self.link.events.get_nowait()
                self.link.belt_cmd(f"CONV,{job['rpm']:.2f}")
            elif job["kind"] == "hold_pose":
                speed = max(90, min(STS_MAX_TICKS_S, int(round(BASE_SPEED * a.arm_speed))))
                self.drive(self.pose(job["pose"]), speed, a.move_timeout, f"task pose '{job['pose']}'")
            elif job["kind"] == "rest":
                job["move_s"] = self.go_rest(job["torque_off"])
            elif job["kind"] == "wake":
                job["move_s"] = self.wake()
            t0 = time.monotonic()
            while time.monotonic() - t0 < job["seconds"]:
                if self.stop_evt.is_set() or not self.pause_evt.is_set():
                    job["error"] = "interrupted (stop or resume)"
                    break
                if job["kind"] != "belt_run":
                    self.hold_tick()
                try:
                    name, args = self.link.events.get_nowait()
                    if name == "FAULT":
                        raise CycleError("FAULT_" + str(args[0] if args else "?"), "belt FAULT during task")
                    if name == "ARRIVED":
                        job["arrived"] = True               # something was on the belt: the Mega braked by itself
                        break
                except queue.Empty:
                    pass
                el = time.monotonic() - t0
                b = self.link.belt
                if b is not None and b["ms"] != last_ms and time.monotonic() - self.link.belt_t < 1.0:
                    last_ms = b["ms"]
                    ma = abs(b["ma"]) if math.isfinite(b["ma"]) else None
                    mv = b["mv"] if math.isfinite(b["mv"]) else None
                    belt.append((el, abs(b["rpm"]), ma, (ma * mv / 1e6) if ma is not None and mv is not None else None))
                if el - last_arm >= 1.0 / a.hz:
                    last_arm = el
                    with self.lock:
                        arm_v = dict(self.live.get("Arm", {}))
                    if arm_v.get("current") is not None:
                        v = arm_v.get("voltage")
                        arm.append((el, arm_v["current"], arm_v["current"] * v / 1000.0 if v is not None else None))
                time.sleep(0.05)
            final = "done" if job["error"] is None else "error"
        except Exception as e:                              # noqa: BLE001 - a failed task is reported, never kills the run
            job["error"] = f"{getattr(e, 'code', type(e).__name__)}: {e}"
        finally:
            if job["kind"] == "belt_run" or (job["error"] or "").startswith("FAULT_"):
                try:                                        # STOP also clears a latched fault, like a failed cycle does
                    self.link.belt_cmd("STOP" if (job["error"] or "").startswith("FAULT_") else "BRAKE")
                except Exception:                           # noqa: BLE001
                    pass
            self.phase = "IDLE"

        def summary(rows, col):
            v = [r[col] for r in rows if r[0] >= job["settle_s"] and r[col] is not None]
            return {"n": len(v), "mean": round(statistics.fmean(v), 3) if v else None,
                    "std": round(statistics.pstdev(v), 3) if len(v) > 1 else None}
        job["stats"] = {"belt_rpm": summary(belt, 1), "belt_mA": summary(belt, 2), "belt_W": summary(belt, 3),
                        "arm_mA": summary(arm, 1), "arm_W": summary(arm, 2)}
        job["t_end"] = time.time()
        job["status"] = final                               # last: a poller that sees done/error also sees the stats
        self.link.note(f"## task {job['id']} {job['status']} {json.dumps(job['stats'])}" + (f" error={job['error']}" if job["error"] else ""))

    # ---------------------------------------------------------------- finished-set bookkeeping
    def finish_set(self):
        end_t = datetime.now().strftime("%H:%M:%S")
        with self.lock:
            rows, line = [], []
            for d in DEVICES:
                for m in METRICS:
                    v = self.set_vals[d][m]
                    g = self.reader.glitches[d] - self.set_glitch0[d] if m == "temp" else ""
                    gc = self.reader.current_glitches[d] - self.set_current_glitch0[d] if m == "current" else ""
                    rows.append([self.set_no, self.set_start, end_t, d, m, len(v),
                                 round(min(v), 2) if v else "", round(statistics.fmean(v), 2) if v else "",
                                 round(max(v), 2) if v else "", g, gc])
                hot = self.set_vals[d]["temp"]
                cur = self.set_vals[d]["current"]
                if d == "Arm" and self.set_vals[d]["voltage"] and cur:
                    vv = self.set_vals[d]["voltage"]
                    line.append(f"ARM TOTAL: servo volt min {min(vv):.1f} V, summed current avg {statistics.fmean(cur):.0f} / peak {max(cur):.0f} mA")
                elif hot and cur:
                    line.append(f"{d}: temp max {max(hot):.0f}C, current avg {statistics.fmean(cur):.0f} / peak {max(cur):.0f} mA")
            self.set_summaries.append(f"Set {self.set_no} ({self.set_start}-{end_t}): " + "; ".join(line))
            self.set_vals = {d: {m: [] for m in METRICS} for d in DEVICES}
            self.set_glitch0 = dict(self.reader.glitches)
            self.set_current_glitch0 = dict(self.reader.current_glitches)
            self.set_start = datetime.now().strftime("%H:%M:%S")
        with open(self.p_sets, "a", newline="", encoding="utf-8") as f:
            csv.writer(f).writerows(rows)
        self.write_thresholds()
        print(self.set_summaries[-1])

    def write_thresholds(self):
        with self.lock:
            snap = {d: {m: list(self.all_vals[d][m]) for m in METRICS} for d in DEVICES}
        with open(self.p_thr, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["device", "metric", "unit", "n", "min", "mean", "std", "p50", "p95", "p99", "max", "mean_plus_3sd"])
            for d in DEVICES:
                for m in METRICS:
                    s = stats(snap[d][m])
                    if s:
                        w.writerow([d, m, UNITS[m], s["n"], s["min"], s["mean"], s["std"], s["p50"], s["p95"], s["p99"],
                                    s["max"], s["mean_plus_3sd"]])

    # ---------------------------------------------------------------- main loop
    def run(self):
        a = self.args
        sampler = threading.Thread(target=self.sampler, daemon=True)
        sampler.start()
        fails = 0
        self.status = "ready"                               # nothing moves until Start is pressed on the web page
        while not self.start_evt.is_set() and not self.stop_evt.is_set():
            time.sleep(0.1)
        if self.stop_evt.is_set() and not self.start_evt.is_set():
            self.status, self.message = "stopped", "quit before start - nothing moved"
            self.raw_f.close()
            return
        try:
            self.status, self.phase = "preparing", "PREPARE"
            if getattr(a, "wdt_auto", False):
                # BUG in the original: the "1500 ms with B / 500 ms without" default was fixed in main(), BEFORE the web page
                # could switch B on, so every run started from the page sent X,WDT,500.  The 210804 log shows 15 belt FAULT_1 in
                # 100 cycles with the PC's X,HB written 0.2-0.26 s earlier and the Mega not silent: two lost heartbeats in a row
                # (KEEPALIVE_S = 0.2 s, 500 ms limit) are enough.  Decide it here, from the value the page really has.
                a.belt_wdt_ms = 1500 if a.enable_b else 500
            self.apply_belt_settings(force=True)            # CPR, TEMPMAX, OFFSET, feeder angles, encoder zero
            self.link.write("X,VER")                        # the reply (build time + diagnostic switches) goes to the TX log
            b = self.link.belt
            if b is not None and math.isnan(b["ma"]):
                msg = ("belt INA260 (D20/D21, addr 0x40) returns nan right at the start: belt current/power will be empty "
                       "- check its VCC/GND/SDA/SCL wires (the 200956 run had this too)")
                self.warnings.append(msg)
                self.link.note("## WARNING " + msg)
                print("WARNING:", msg)
            if self.rest_state != "awake":                  # --resting: the arm is on the cradle; Home from here hits the frame
                self.hold = {}                              # nothing to supervise: the cradle carries the arm
                self.pause_evt.set()
                self.link.note("## start while resting: nothing moves, paused until the wake task")
                print("arm resting: paused - send the wake task, then Resume")
                self.wait_if_paused()                       # runs the wake task (ends at Home); leaves once awake AND resumed
            speed = max(90, min(STS_MAX_TICKS_S, int(round(BASE_SPEED * a.arm_speed))))
            self.gripper(self.args.open_pos, "open at start")
            self.drive(self.pose("right"), speed, self.args.move_timeout, "home at start")
            if a.enable_b:
                # feature B: the pipelined cycle assumes a block is ALREADY waiting at the IR when it
                # starts (so GRIP has something to close on immediately) -- there is no "previous cycle" to
                # have prefetched it for cycle 1, so do the ORIGINAL serial FEED+TRANSPORT once, here,
                # before the overlapped loop begins.
                self.feed_and_transport_to_ir(speed)
            self.status = "running"
            s = 0
            while s < a.sets:                               # a.sets can be changed from the web page while running
                if a.pause_before_set:                      # experiment.py: hold before every set (= one block) until resumed
                    self.pause_evt.set()
                    self.set_boundary = True                # stays True if Stop ends the run here (see finally below)
                    self.wait_if_paused()
                    self.set_boundary = False
                s += 1
                self.set_no = s
                cps = a.cycles_per_set                      # a change of cycles/set applies from the next set
                for c in range(1, cps + 1):
                    if self.stop_evt.is_set():
                        raise InterruptedError("stopped")
                    self.cycle_in_set, self.cycle_total = c, self.cycle_total + 1
                    t_start, iso = time.monotonic(), datetime.now().isoformat(timespec="seconds")
                    result, notes = "OK", ""
                    recovery_error = None
                    try:
                        self.one_cycle_pipelined() if a.enable_b else self.one_cycle()
                        fails = 0
                    except InterruptedError:
                        raise
                    except Exception as e:                  # noqa: BLE001 - log it, clear the belt fault, carry on
                        result, notes = getattr(e, "code", type(e).__name__), str(e)
                        if result != "NO_BLOCK":            # the orchestrator's own abort of an empty feed is not a fault
                            fails += 1
                        try:
                            self.link.belt_cmd("STOP")      # brake/coast + clear a latched fault
                        except Exception:                   # noqa: BLE001
                            pass
                        if a.enable_c:
                            self.q_extra = None             # feature C: after a failure nobody knows where the queued block is
                        if result == "FAULT_2":             # belt over-temperature: do not go on
                            raise RuntimeError("belt over-temperature fault - stopping")
                        if a.enable_recover and a.enable_b:   # put arm + belt back to "open at Standby, block at the IR"
                            try:
                                self.recover(result)
                            except InterruptedError:
                                raise
                            except Exception as re:         # noqa: BLE001 - logged, then the run ends after this cycle's row
                                recovery_error = re
                                self.cycle_notes.append(f"RECOVERY FAILED: {type(re).__name__}: {re}")
                    result, notes = self.grade_grip(result, notes)      # OK -> GRIP_SUSPECT if the block was probably not held
                    if self.cycle_notes:
                        notes = (notes + " | " if notes else "") + "; ".join(self.cycle_notes)
                    self.cycle_notes = []
                    secs = round(time.monotonic() - t_start, 1)
                    with open(self.p_cyc, "a", newline="", encoding="utf-8") as f:
                        now_t = time.monotonic()
                        self.phase_times[self._phase] = self.phase_times.get(self._phase, 0.0) + now_t - self._phase_t0
                        self._phase_t0 = now_t
                        pt = self.phase_times
                        cj6 = self.j6_carry       # feature D monitoring: this cycle's CARRY-phase J6 range
                        csv.writer(f).writerow([s, c, self.cycle_total, iso, secs, result, self.cycle_info["drop"],
                                                self.cycle_info["travel"], round(pt.get("FEED", 0), 1),
                                                round(pt.get("TRANSPORT", 0), 1), round(pt.get("GRIP", 0), 1),
                                                round(sum(v for k, v in pt.items() if k.startswith("CARRY")), 1), notes,
                                                round(cj6["cur_max"], 0) if cj6["cur_max"] is not None else "",
                                                round(cj6["pos_max"] - cj6["pos_min"], 2) if cj6["pos_min"] is not None else "",
                                                a.grip_hold_preload if a.enable_d else "",
                                                a.grip_hold_torque_limit if a.enable_d else "",
                                                round(self.cycle_info["grip_contact_ticks"] * 360.0 / 4096.0, 1)
                                                if isinstance(self.cycle_info["grip_contact_ticks"], (int, float)) else "",
                                                self.cycle_info["ir_at_grip"], self.cycle_info["crawl_s"],
                                                self.cycle_info["conv_start_s"], self.cycle_info["recovery"], self.cycle_info["queue"],
                                                self.cycle_info["gate_wait_s"]])
                    self.cycle_log.append({"n": self.cycle_total, "set": s, "result": result, "secs": secs, "notes": notes,
                                           "drop": self.cycle_info["drop"]})      # the bin, for the orchestrator's sort check
                    if self.mq:
                        self.mq.cycle({"n": self.cycle_total, "set": s, "cycle_in_set": c, "result": result,
                                       "secs": secs, "drop": self.cycle_info["drop"], "notes": notes})
                    print(f"set {s}/{a.sets} cycle {c}/{cps}  {result} {secs}s {notes}")
                    if recovery_error is not None:
                        raise RuntimeError(f"recovery after {result} failed ({recovery_error}) - stopping instead of gripping blind")
                    if fails >= a.max_fails:
                        raise RuntimeError(f"{a.max_fails} failed cycles in a row - stopping")
                    self.dwell(a.gap)
                    self.wait_if_paused()
                self.cycle_in_set = cps
                self.finish_set()
            self.status, self.message = "finished", f"{s} sets done"
        except InterruptedError:
            self.status, self.message = "stopped", "stopped by the operator"
        except Exception as e:                              # noqa: BLE001
            self.status, self.message = "error", f"{type(e).__name__}: {e}"
            print("STOPPED:", self.message)
        finally:
            self.phase = "IDLE"
            try:
                self.link.belt_cmd("STOP")                  # belt coasts, fault cleared
            except Exception:                               # noqa: BLE001
                pass
            for sid in range(1, 6):
                self.link.write(f"H,{sid}")                 # arm holds where it is
            time.sleep(0.5)
            if self.status != "finished" and not self.set_boundary and any(self.set_vals[d]["temp"] for d in DEVICES if d != "Arm"):
                self.finish_set()                           # keep the unfinished set (partial) as well
            self.write_thresholds()
            self.raw_f.flush()
            self.raw_f.close()
            sampler.join(timeout=2)

    # ---------------------------------------------------------------- live settings (from the web page)
    LIMITS = {"sets": (1, 1000, int), "cycles_per_set": (1, 1000, int), "arm_speed": (0.2, 8.8, float),
              "carry_speed": (0.2, 8.8, float), "rpm": (0.5, 37.0, float), "offset": (0, 5000, int),
              "gap": (0.0, 60.0, float), "hz": (1.0, 20.0, float), "gripper_speed": (100, 3200, int), "acc": (0, 254, int),
              "open_pos": (1800, 3100, int), "dwell_standby": (0.0, 30.0, float), "dwell_grip": (0.0, 30.0, float),
              "dwell_drop": (0.0, 30.0, float), "dwell_home": (0.0, 30.0, float),
              "pose_tol": (10, 100, int), "grip_tol": (5, 100, int), "move_timeout": (5.0, 120.0, float),
              "feed_timeout": (1.0, 30.0, float), "arrive_timeout": (5.0, 120.0, float),
              "clear_timeout": (0.5, 20.0, float), "standby_timeout": (10.0, 120.0, float),
              "grip_timeout": (3.0, 30.0, float), "max_fails": (1, 20, int),
              "hold_tol": (0, 300, int), "settle_tol": (0, 300, int), "temp_max": (0.0, 100.0, float),
              "belt_wdt_ms": (0, 10000, int),
              "feeder_home": (0, 180, int), "feeder_push": (0, 180, int),
              "feeder_push_ms": (50, 2000, int), "feeder_return_ms": (50, 2000, int),
              "kp": (0.0, 20.0, float), "ki": (0.0, 50.0, float), "kd": (0.0, 5.0, float),
              # feature A / D (see close_gripper's docstring): all live-tunable so each can be
              # switched off or re-tuned between runs without touching the command line.
              "enable_a": (0, 1, int), "grip_fast_to_pos": (1800, 3100, int),
              "grip_fast_speed": (100, 3200, int), "grip_fast_acc": (0, 254, int),
              "grip_fast_timeout": (0.5, 10.0, float),
              "grip_pos": (0, 3100, int), "grip_pos_speed": (50, 3200, int),
              "enable_d": (0, 1, int), "grip_hold_preload": (0, 300, int),
              "grip_hold_torque_limit": (0, 1000, int),
              # feature B: settable here (so it still shows/validates through the same settings API) but
              # set_config() above refuses to change it once the run is not "ready" -- see that guard.
              "enable_b": (0, 1, int),
              # verification / recovery (see verify_grip, grade_grip, recover)
              "enable_verify": (0, 1, int), "grip_contact_min_deg": (100.0, 250.0, float),
              "grip_contact_max_deg": (100.0, 250.0, float), "grip_carry_min_ma": (0.0, 1000.0, float),
              "grip_slip_max_deg": (0.1, 90.0, float), "enable_recover": (0, 1, int), "recover_conv_s": (1.0, 30.0, float),
              "ir_confirm_s": (0.0, 5.0, float),
              "enable_c": (0, 1, int), "queue_split": (0.2, 0.8, float), "pause_before_set": (0, 1, int),
              "arrival_guard": (0, 1, int), "arrival_margin_s": (0.0, 5.0, float)}
    CHOICES = {"drop_mode": ("alternate", "left", "down"), "first_drop": ("left", "down")}

    def set_config(self, new):
        """Validate and apply settings. settings act from the next cycle, cycles_per_set from the next set."""
        clean = {}
        for k, v in new.items():
            if k in self.CHOICES:
                if v not in self.CHOICES[k]:
                    raise ValueError(f"{k} must be one of {self.CHOICES[k]}")
                clean[k] = v
                continue
            if k not in self.LIMITS:
                raise ValueError(f"unknown setting {k}")
            lo, hi, typ = self.LIMITS[k]
            v = typ(v)
            if not (lo <= v <= hi):
                raise ValueError(f"{k} must be {lo}..{hi}")
            clean[k] = v
        if "sets" in clean and self.status == "running" and clean["sets"] < self.set_no:
            raise ValueError(f"sets must be at least the current set ({self.set_no})")
        # feature B: the pipelined cycle assumes a block is already waiting at the IR and the serial cycle
        # does not (and they leave the arm in different poses at the IDLE boundary -- Standby vs Home) --
        # flipping between them mid-run skips the bootstrap/cleanup each one relies on and can jam the
        # belt or try to grip nothing. Only settable before Start (the web page's "ready" state).
        if "enable_b" in clean and self.status != "ready" and clean["enable_b"] != self.args.enable_b:
            raise ValueError("enable_b can only be changed before Start (stop and restart the run to change it)")
        # feature C keeps track of where blocks sit on the belt, so it can only be switched while nothing is running
        if "enable_c" in clean and self.status != "ready" and clean["enable_c"] != self.args.enable_c:
            raise ValueError("enable_c can only be changed before Start (stop and restart the run to change it)")
        for k, v in clean.items():
            setattr(self.args, k, v)
        print("settings changed from the web page:", clean)
        return clean

    def config(self):
        return {k: getattr(self.args, k) for k in list(self.LIMITS) + list(self.CHOICES)}

    # ---------------------------------------------------------------- for the web page
    def snapshot(self):
        with self.lock:
            live = {d: dict(v) for d, v in self.live.items()}
        return {"status": self.status, "message": self.message, "phase": self.phase, "set": self.set_no,
                "sets": self.args.sets, "cycle_in_set": self.cycle_in_set, "cycles_per_set": self.args.cycles_per_set,
                "cycle_total": self.cycle_total, "elapsed": round(time.monotonic() - self.t0), "live": live,
                "units": UNITS, "devices": DEVICES, "metrics": METRICS, "set_summaries": self.set_summaries[-20:],
                "config": self.config(), "warnings": self.warnings, "drifts": self.total_excursions, "paused": self.pause_evt.is_set(), "cycles": self.cycle_log[-12:], "files": [self.p_raw, self.p_sets, self.p_cyc, self.p_thr],
                "mqtt": self.mq.info() if self.mq else None, "task": dict(self.task) if self.task else None,
                "set_boundary": self.set_boundary, "rest_state": self.rest_state}


PAGE = r"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>autoen_node</title><style>
:root{--bg:#f6f7f9;--card:#fff;--ink:#14181f;--mut:#5d6675;--line:#dfe3ea;--acc:#0b6bcb;--bad:#c42b2b}
@media (prefers-color-scheme:dark){:root{--bg:#10141a;--card:#181e27;--ink:#e8ecf2;--mut:#98a2b3;--line:#2a3340;--acc:#5aa9ff;--bad:#ff6b6b}}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.45 system-ui,Segoe UI,sans-serif}
main{max-width:980px;margin:0 auto;padding:16px}h1{font-size:20px;margin:0 0 10px}h2{font-size:15px;margin:0 0 6px}
.card{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:14px;margin-bottom:12px;overflow-x:auto}
.mut{color:var(--mut)}table{border-collapse:collapse;width:100%}th,td{padding:5px 8px;border-bottom:1px solid var(--line);text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}
th:first-child,td:first-child{text-align:left}th{font-size:12px;color:var(--mut)}
.bar{height:8px;border-radius:99px;background:var(--line);overflow:hidden;margin:6px 0}.bar>i{display:block;height:100%;background:var(--acc)}
button{font:inherit;font-weight:600;border:0;border-radius:8px;padding:8px 16px;background:var(--bad);color:#fff;cursor:pointer}
li{margin:3px 0}</style></head><body><main>
<h1>autoen_node <span class="mut" id="st"></span> <button id="stop">&#9632; Stop</button> <button id="pause" style="background:#8a6d00">&#10074;&#10074; Pause</button></h1>
<div class="card"><div id="prog"></div><div class="bar"><i id="bar" style="width:0"></i></div><div class="mut" id="msg"></div><div class="mut" id="mq"></div></div>
<div class="card"><h2>Settings <span class="mut" id="cfghint"></span></h2>
<form id="cfg" style="display:flex;flex-wrap:wrap;gap:10px;align-items:end">
<label>Sets<br><input name="sets" type="number" min="1" max="1000" step="1" style="width:70px"></label>
<label>Cycles / set<br><input name="cycles_per_set" type="number" min="1" max="1000" step="1" style="width:80px"></label>
<label>Arm speed (0.2-8.8, x360 t/s; 8.8 = 3200 max)<br><input name="arm_speed" type="number" min="0.2" max="8.8" step="0.1" style="width:90px"></label>
<label>Carry speed (0.2-8.8, x360 t/s)<br><input name="carry_speed" type="number" min="0.2" max="8.8" step="0.1" style="width:90px"></label>
<label>Belt RPM (to IR, output shaft, 12V 1:270: no-load 37)<br><input name="rpm" type="number" min="0.5" max="37" step="0.1" style="width:80px"></label>
<label>Offset after IR (counts)<br><input name="offset" type="number" min="0" max="5000" step="10" style="width:90px"></label>
<label>Drop order<br><select name="drop_mode"><option>alternate</option><option>left</option><option>down</option></select></label>
<label>First drop<br><select name="first_drop"><option>left</option><option>down</option></select></label>
<label>Gap s<br><input name="gap" type="number" min="0" max="60" step="0.5" style="width:70px"></label>
<label>Samples/s<br><input name="hz" type="number" min="1" max="20" step="1" style="width:70px"></label>
<label>Servo ACC (0-254, x100 t/s2; needs ACC firmware)<br><input name="acc" type="number" min="0" max="254" step="1" style="width:80px"></label>
<label>Gripper speed<br><input name="gripper_speed" type="number" min="100" max="3200" step="50" style="width:90px"></label>
<label>Gripper open pos<br><input name="open_pos" type="number" min="1800" max="3100" step="10" style="width:90px"></label>
<label>Feature B: pipeline FEED+belt (1/0, set before Start only)<br><input name="enable_b" type="number" min="0" max="1" step="1" style="width:60px"></label>
<label>Feature A: 2-stage close (1/0)<br><input name="enable_a" type="number" min="0" max="1" step="1" style="width:60px"></label>
<label>A: fast-close target ticks<br><input name="grip_fast_to_pos" type="number" min="1800" max="3100" step="10" style="width:90px"></label>
<label>Grip position ticks (0 = close until stall)<br><input name="grip_pos" type="number" min="0" max="3100" step="1" style="width:90px"></label>
<label>Grip position speed<br><input name="grip_pos_speed" type="number" min="50" max="3200" step="50" style="width:80px"></label>
<label>A: fast-close speed<br><input name="grip_fast_speed" type="number" min="100" max="3200" step="50" style="width:90px"></label>
<label>A: fast-close acc (0-254)<br><input name="grip_fast_acc" type="number" min="0" max="254" step="1" style="width:70px"></label>
<label>A: fast-close timeout s<br><input name="grip_fast_timeout" type="number" min="0.5" max="10" step="0.5" style="width:80px"></label>
<label>Feature D: hold preload/torque (1/0)<br><input name="enable_d" type="number" min="0" max="1" step="1" style="width:60px"></label>
<label>D: hold preload ticks<br><input name="grip_hold_preload" type="number" min="0" max="300" step="10" style="width:80px"></label>
<label>D: hold torque limit (0-1000)<br><input name="grip_hold_torque_limit" type="number" min="0" max="1000" step="50" style="width:90px"></label>
<label>Dwell standby s<br><input name="dwell_standby" type="number" min="0" max="30" step="0.5" style="width:80px"></label>
<label>Dwell after grip s<br><input name="dwell_grip" type="number" min="0" max="30" step="0.5" style="width:80px"></label>
<label>Dwell at drop s<br><input name="dwell_drop" type="number" min="0" max="30" step="0.5" style="width:80px"></label>
<label>Dwell home s<br><input name="dwell_home" type="number" min="0" max="30" step="0.5" style="width:80px"></label>
<label>Feed timeout s<br><input name="feed_timeout" type="number" min="1" max="30" step="1" style="width:80px"></label>
<label>Arrive (IR) timeout s<br><input name="arrive_timeout" type="number" min="5" max="120" step="5" style="width:80px"></label>
<label>Grip timeout s<br><input name="grip_timeout" type="number" min="3" max="30" step="1" style="width:80px"></label>
<label>Clear-IR timeout s<br><input name="clear_timeout" type="number" min="0.5" max="20" step="0.5" style="width:80px"></label>
<label>Standby timeout s<br><input name="standby_timeout" type="number" min="10" max="120" step="5" style="width:80px"></label>
<label>Move timeout s<br><input name="move_timeout" type="number" min="5" max="120" step="5" style="width:80px"></label>
<label>Pose tol (ticks)<br><input name="pose_tol" type="number" min="10" max="100" step="5" style="width:80px"></label>
<label>Grip tol (ticks)<br><input name="grip_tol" type="number" min="5" max="100" step="5" style="width:80px"></label>
<label>Drift tol (ticks, 0=off)<br><input name="hold_tol" type="number" min="0" max="300" step="10" style="width:90px"></label>
<label>Settle tol (ticks, 0=off)<br><input name="settle_tol" type="number" min="0" max="300" step="10" style="width:90px"></label>
<label>Stop after N fails<br><input name="max_fails" type="number" min="1" max="20" step="1" style="width:80px"></label>
<label>Belt temp max C<br><input name="temp_max" type="number" min="0" max="100" step="5" style="width:80px"></label>
<label>Belt watchdog ms (0=off)<br><input name="belt_wdt_ms" type="number" min="0" max="10000" step="100" style="width:80px"></label>
<label>Belt PID Kp<br><input name="kp" type="number" min="0" max="20" step="0.1" style="width:80px"></label>
<label>Belt PID Ki<br><input name="ki" type="number" min="0" max="50" step="0.1" style="width:80px"></label>
<label>Belt PID Kd<br><input name="kd" type="number" min="0" max="5" step="0.05" style="width:80px"></label>
<label>Feeder home angle<br><input name="feeder_home" type="number" min="0" max="180" step="5" style="width:80px"></label>
<label>Feeder push angle<br><input name="feeder_push" type="number" min="0" max="180" step="5" style="width:80px"></label>
<label>Feeder push ms<br><input name="feeder_push_ms" type="number" min="50" max="2000" step="50" style="width:80px"></label>
<label>Feeder return ms<br><input name="feeder_return_ms" type="number" min="50" max="2000" step="50" style="width:80px"></label>
<label>Verify grip (1/0)<br><input name="enable_verify" type="number" min="0" max="1" step="1" style="width:60px"></label>
<label>Block window min deg<br><input name="grip_contact_min_deg" type="number" min="100" max="250" step="0.5" style="width:80px"></label>
<label>Block window max deg<br><input name="grip_contact_max_deg" type="number" min="100" max="250" step="0.5" style="width:80px"></label>
<label>Carry current min mA (else GRIP_SUSPECT)<br><input name="grip_carry_min_ma" type="number" min="0" max="1000" step="10" style="width:90px"></label>
<label>Carry slip max deg (else GRIP_SUSPECT)<br><input name="grip_slip_max_deg" type="number" min="0.1" max="90" step="0.5" style="width:90px"></label>
<label>Recover after a failed cycle (1/0, pipeline)<br><input name="enable_recover" type="number" min="0" max="1" step="1" style="width:60px"></label>
<label>Recovery belt run s<br><input name="recover_conv_s" type="number" min="1" max="30" step="1" style="width:80px"></label>
<label>Feature C: belt queue (1/0, needs B, set before Start only)<br><input name="enable_c" type="number" min="0" max="1" step="1" style="width:60px"></label>
<label>Arrival guard (1/0): block may not arrive before the arm is parked<br><input name="arrival_guard" type="number" min="0" max="1" step="1" style="width:60px"></label>
<label>Arrival margin s<br><input name="arrival_margin_s" type="number" min="0" max="5" step="0.1" style="width:80px"></label>
<label>Queue feed point (fraction of full travel)<br><input name="queue_split" type="number" min="0.2" max="0.8" step="0.05" style="width:80px"></label>
<button type="submit" style="background:var(--acc)">Apply</button><span id="cfgmsg" class="mut"></span></form>
<div id="startrow" style="margin-top:12px;display:flex;gap:12px;align-items:center;flex-wrap:wrap">
<label><input type="checkbox" id="clear"> Arm area is clear and the E-stop is within reach</label>
<button id="start" style="background:#1a8a3c">&#9654; Start run</button></div></div>
<div class="card"><table id="live"></table></div>
<div class="card"><h2>Finished sets</h2><ul id="sets" class="mut"></ul></div>
<div class="card"><h2>Last cycles</h2><table id="cyc"></table><div class="mut" id="files" style="margin-top:6px"></div></div>
<script>
const $=id=>document.getElementById(id),f=(v,d)=>v===null||v===undefined?'-':(+v).toFixed(d);
$('stop').onclick=()=>fetch('/api/stop',{method:'POST'});
$('pause').onclick=()=>fetch('/api/pause',{method:'POST'});
let cfgFilled=false;
const form=()=>{const o={};new FormData($('cfg')).forEach((v,k)=>{if(v!=='')o[k]=['drop_mode','first_drop'].includes(k)?v:+v});return o};
$('cfg').onsubmit=async e=>{e.preventDefault();
 const r=await fetch('/api/config',{method:'POST',body:JSON.stringify(form())});const j=await r.json();
 $('cfgmsg').textContent=r.ok?' applied':' '+(j.error||'error');};
$('start').onclick=async()=>{
 const r=await fetch('/api/start',{method:'POST',body:JSON.stringify({clear:$('clear').checked,config:form()})});const j=await r.json();
 $('cfgmsg').textContent=r.ok?' started':' '+(j.error||'error');};
async function tick(){try{const s=await (await fetch('/api/state')).json();
 $('st').textContent=s.status+' / '+s.phase;
 $('startrow').style.display=s.status==='ready'?'flex':'none';
 $('pause').style.display=s.status==='ready'?'none':'inline-block';
 $('pause').innerHTML=s.paused?'&#9654; Resume':'&#10074;&#10074; Pause after this cycle';
 $('stop').innerHTML=s.status==='ready'?'&#9632; Quit':'&#9632; Stop';
 $('cfghint').textContent=s.status==='ready'?'(set everything, tick the box, press Start)':'(all apply from the next cycle; cycles per set from the next set; samples/s at once)';
 if(!cfgFilled&&s.config){cfgFilled=true;for(const k in s.config){const i=document.querySelector('[name='+k+']');if(i)i.value=s.config[k];}}
 const done=(s.set-1)*s.cycles_per_set+s.cycle_in_set,tot=s.sets*s.cycles_per_set;
 $('prog').innerHTML='<b>Set '+s.set+' / '+s.sets+'</b> &middot; drifts corrected '+s.drifts+' &middot; cycle '+s.cycle_in_set+' / '+s.cycles_per_set+' &middot; total '+s.cycle_total+' / '+tot+' &middot; '+Math.floor(s.elapsed/60)+' min';
 $('bar').style.width=Math.min(100,100*s.cycle_total/tot)+'%';$('msg').textContent=s.message+(s.warnings&&s.warnings.length?'   WARNING: '+s.warnings.join(' | '):'');$('mq').textContent=s.mqtt?('MQTT '+s.mqtt.host+':'+s.mqtt.port+' | arm '+(s.mqtt.arm_up?'connected':'NOT connected')+' | belt '+(s.mqtt.belt_up?'connected':'NOT connected')+' | published '+s.mqtt.sent):'MQTT off';
 let h='<tr><th>device</th><th>temp C</th><th>current mA</th><th>velocity</th><th>position</th><th>volt V</th></tr>';
 s.devices.forEach(d=>{const x=s.live[d],b=d==='Belt';if(d==='Arm'){}h+='<tr><td>'+(d==='Belt'?'Belt motor':d==='Arm'?'Arm total (sum I, min V)':'Joint '+d.slice(1))+'</td><td>'+f(x.temp,1)+'</td><td>'+f(x.current,0)+'</td><td>'+f(x.velocity,1)+(b?' rpm':' deg/s')+'</td><td>'+f(x.position,b?2:1)+(b?' rev':' deg')+'</td><td>'+f(x.voltage,2)+'</td></tr>';});
 $('live').innerHTML=h;
 $('sets').innerHTML=s.set_summaries.slice().reverse().map(x=>'<li>'+x+'</li>').join('')||'<li>none yet</li>';
 $('cyc').innerHTML='<tr><th>#</th><th>set</th><th>result</th><th>sec</th><th>notes</th></tr>'+s.cycles.slice().reverse().map(c=>'<tr><td>'+c.n+'</td><td>'+c.set+'</td><td>'+c.result+'</td><td>'+c.secs+'</td><td style="text-align:left">'+(c.notes||'')+'</td></tr>').join('');
 $('files').textContent='files: '+s.files.join('  |  ');}catch(e){}}
setInterval(tick,1000);tick();
</script></main></body></html>"""


def serve(study, port, host="127.0.0.1"):
    """Tiny web page (127.0.0.1 only unless --web-host): live values, progress, parameters, Start / Stop."""
    loopback = host in ("127.0.0.1", "localhost")

    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _allowed(self, post):
            """The page can move the robot, so a web page open in another tab must not be able to press Start:
            on loopback the Host header must be 127.0.0.1/localhost (blocks DNS rebinding), and a POST that carries
            an Origin must come from this very page (blocks cross-site requests)."""
            h = self.headers.get("Host", "")
            if loopback and h.split(":")[0] not in ("127.0.0.1", "localhost"):
                return False
            org = self.headers.get("Origin")
            return not (post and org and org.split("://", 1)[-1] != h)

        def _send(self, body, ctype):
            data = body.encode() if isinstance(body, str) else json.dumps(body).encode()
            self.send_response(200)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(data)

        def do_GET(self):
            if not self._allowed(False):
                self.send_error(403, "bad Host header")
                return
            if self.path.startswith("/api/state"):
                self._send(study.snapshot(), "application/json")
            else:
                self._send(PAGE, "text/html; charset=utf-8")

        def do_POST(self):
            if not self._allowed(True):
                self.send_error(403, "cross-site request refused")
                return
            if self.path.startswith("/api/stop"):
                study.stop_evt.set()
            elif self.path.startswith("/api/pause"):
                if study.pause_evt.is_set() and study.rest_state != "awake":
                    data = json.dumps({"error": f"the arm is resting ({study.rest_state}): send the wake task first"}).encode()
                    self.send_response(409)
                    self.send_header("Content-Type", "application/json")
                    self.send_header("Content-Length", str(len(data)))
                    self.end_headers()
                    self.wfile.write(data)
                    return
                if study.pause_evt.is_set():
                    study.pause_evt.clear()
                else:
                    study.pause_evt.set()
            elif self.path.startswith("/api/start"):
                try:
                    n = int(self.headers.get("Content-Length", 0))
                    body = json.loads(self.rfile.read(n) or b"{}")
                    if study.status != "ready":
                        raise ValueError(f"cannot start: status is {study.status}")
                    if body.get("clear") is not True:
                        raise ValueError("tick 'arm area is clear' first")
                    study.set_config(body.get("config", {}))
                    study.start_evt.set()
                except (ValueError, TypeError, json.JSONDecodeError) as e:
                    data = json.dumps({"error": str(e)}).encode()
                    self.send_response(400)
                    self.send_header("Content-Type", "application/json")
                    self.send_header("Content-Length", str(len(data)))
                    self.end_headers()
                    self.wfile.write(data)
                    return
                self._send({"started": True}, "application/json")
                return
            elif self.path.startswith("/api/config"):
                try:
                    n = int(self.headers.get("Content-Length", 0))
                    applied = study.set_config(json.loads(self.rfile.read(n) or b"{}"))
                except (ValueError, TypeError, json.JSONDecodeError) as e:
                    data = json.dumps({"error": str(e)}).encode()
                    self.send_response(400)
                    self.send_header("Content-Type", "application/json")
                    self.send_header("Content-Length", str(len(data)))
                    self.end_headers()
                    self.wfile.write(data)
                    return
                self._send({"applied": applied}, "application/json")
                return
            elif self.path.startswith("/api/abort_transport"):
                try:
                    out = study.abort_transport()
                except ValueError as e:
                    data = json.dumps({"error": str(e)}).encode()
                    self.send_response(409)
                    self.send_header("Content-Type", "application/json")
                    self.send_header("Content-Length", str(len(data)))
                    self.end_headers()
                    self.wfile.write(data)
                    return
                self._send(out, "application/json")
                return
            elif self.path.startswith("/api/task"):
                try:
                    n = int(self.headers.get("Content-Length", 0))
                    task = study.submit_task(json.loads(self.rfile.read(n) or b"{}"))
                except (ValueError, TypeError, json.JSONDecodeError) as e:
                    data = json.dumps({"error": str(e)}).encode()
                    self.send_response(400)
                    self.send_header("Content-Type", "application/json")
                    self.send_header("Content-Length", str(len(data)))
                    self.end_headers()
                    self.wfile.write(data)
                    return
                self._send({"task": dict(task)}, "application/json")
                return
            self._send({}, "application/json")

    srv = ThreadingHTTPServer((host, port), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv


# ====================================================================== entry point
def find_serial_port():
    """Mega shows up as ttyACM* (genuine) or ttyUSB* (CH340 clone); the number can change on replug."""
    for pattern in ("/dev/prism-mega", "/dev/serial/by-id/*", "/dev/ttyACM*", "/dev/ttyUSB*"):
        found = sorted(glob.glob(pattern))
        if found:
            return found[0]
    raise SystemExit("No Mega found: nothing in /dev/serial/by-id, /dev/ttyACM* or /dev/ttyUSB*. Is the USB cable plugged in?")


GRIP_CAL_KEYS = ("open_pos", "grip_fast_to_pos", "grip_contact_min_deg", "grip_contact_max_deg", "grip_pos")


def load_grip_cal(path):
    """gripper_cal.json from grip_calibrate.py -> the gripper defaults it sets ({} if there is no file)."""
    if not path or not os.path.exists(path):
        return {}
    with open(path, "r", encoding="utf-8") as f:
        cal = json.load(f)
    found = {k: cal[k] for k in GRIP_CAL_KEYS if cal.get(k) is not None}
    print(f"gripper calibration {path} ({cal.get('measured_at')}): " + ", ".join(f"{k}={v}" for k, v in found.items()))
    return found


def build_parser():
    ap = argparse.ArgumentParser(description="autoen_node: arm + conveyor + feeder real pick cycle with a parameter dashboard, recording and MQTT")
    ap.add_argument("--port", default=os.environ.get("ARM_SERIAL_PORT") or ("COM6" if os.name == "nt" else None),
                    help="Mega serial port (env ARM_SERIAL_PORT); default = auto-detect")
    ap.add_argument("--awake", action="store_true",
                    help="the arm is NOT on the cradle, whatever rest_state.json says (it was moved off by hand)")
    ap.add_argument("--rest-file", default=None,
                    help=f"where the arm's rest state is remembered (default {REST_FILE}; '' = no memory; "
                         "always off with --port SIMULATED)")
    ap.add_argument("--resting", action="store_true",
                    help="the arm is on the cradle (autoen was restarted while it rested): Start moves nothing and "
                         "waits, paused, for the wake task (POST /api/task {\"kind\": \"wake\"}), then Resume")
    ap.add_argument("--pose-config", default=POSE_CONFIG,
                    help="extra poses + rest/wake sequences (default PRISM/config/poses.json; '' = no rest pose)")
    ap.add_argument("--poses", default=None, help="optional poses file (so101_dpad_poses.json: up/right/left/down); default = the built-in poses of arm_node.py")
    ap.add_argument("--grip-cal", default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "gripper_cal.json"),
                    help="gripper calibration from grip_calibrate.py: its open / fast-close / block-window values become "
                         "the defaults (options given here still win). '' = ignore it")
    ap.add_argument("--mqtt-host", default=os.environ.get("MQTT_HOST", "localhost"), help="broker (env MQTT_HOST)")
    ap.add_argument("--mqtt-port", type=int, default=1883)
    ap.add_argument("--mqtt-hz", type=float, default=10.0, help="arm/telemetry rate")
    ap.add_argument("--no-mqtt", action="store_true", help="run without a broker (the recording and the page still work)")
    ap.add_argument("--web-host", default="127.0.0.1", help="address of the page; 0.0.0.0 exposes a page that can MOVE THE ROBOT to your network")
    ap.add_argument("--sets", type=int, default=2)
    ap.add_argument("--cycles-per-set", type=int, default=6, help="default 2 sets x 6 = one magazine of 12 blocks")
    ap.add_argument("--rpm", type=float, default=6.7,
                    help="belt speed to the IR, real output-shaft rpm (CPR 11880; the old '60' at CPR 1320 = 6.7)")
    ap.add_argument("--arm-speed", type=float, default=1.0, help="1.0 = the project's normal pose speed")
    ap.add_argument("--gap", type=float, default=1.0, help="pause between cycles, s")
    ap.add_argument("--hz", type=float, default=5.0, help="samples per second")
    ap.add_argument("--drop-mode", choices=["alternate", "left", "down"], default="alternate")
    ap.add_argument("--first-drop", choices=["left", "down"], default="left", help="side of the first drop when alternating")
    ap.add_argument("--carry-speed", type=float, default=1.0, help="speed factor after the grip (Home and drop legs)")
    ap.add_argument("--gripper-speed", type=int, default=GRIPPER_SPEED)
    ap.add_argument("--acc", type=int, default=8, help="servo acceleration 0-254 (x100 ticks/s2), sent as the 4th field of P; 8 = the firmware default; only the ACC firmware reads it")
    ap.add_argument("--open-pos", type=int, default=None, help="gripper open ticks (default: see --grip-open-pos-a / pose 'up')")
    # ---- feature A: two-stage gripper close (fast P move, then only the last bit with the stall-crawl)
    ap.add_argument("--enable-a", type=int, default=1, choices=[0, 1],
                    help="feature A: fast pre-close P move + a lower default gripper-open position. "
                         "0 = exact original behaviour (open_pos from pose 'up', single-speed stall-crawl all the way)")
    ap.add_argument("--grip-open-pos-a", type=int, default=2445,
                    help="feature A: --open-pos default used when --open-pos is not given and --enable-a=1 "
                         "(~215 deg, was ~249 deg from pose 'up'). UNVERIFIED on real blocks -- confirm the "
                         "gripper still clears a block at this opening before trusting it")
    ap.add_argument("--grip-fast-to-pos", type=int, default=2276,
                    help="feature A: fast P-move target before the stall-crawl takes over, ticks (~200 deg). "
                         "Must stay ABOVE the real block height (open_pos is in ticks too; smaller ticks = more "
                         "closed) or the fast move has no stall protection and can hit the block hard. "
                         "UNVERIFIED -- check against a real block first")
    ap.add_argument("--grip-pos", type=int, default=0,
                    help="close the gripper to exactly this J6 position (ticks, taught on a real block with "
                         "grip_calibrate.py) and stop there, instead of the firmware stall-crawl that closes until the "
                         "jaws cannot move (that crunched blocks). 0 = stall-crawl")
    ap.add_argument("--grip-pos-speed", type=int, default=400, help="ticks/s of the last move to --grip-pos")
    ap.add_argument("--grip-fast-speed", type=int, default=1800,
                    help="feature A: speed of the fast pre-close P move, ticks/s (max 3200). ROUND 1 FINDING: "
                         "a short one-shot P move is acceleration-bound, not speed-bound, so raising this alone "
                         "does nothing -- see --grip-fast-acc")
    ap.add_argument("--grip-fast-acc", type=int, default=70,
                    help="feature A: servo acceleration (0-254, x100 ticks/s^2) for JUST the fast pre-close "
                         "move; every other move still uses --acc. ROUND 1 measured the default --acc (8) "
                         "making a 170-tick fast move take 0.86s (acceleration-bound: t=2*sqrt(distance/acc)); "
                         "ROUND 2 confirmed 48 (4800 ticks/s^2) cut that to ~0.38s, matching the same formula, "
                         "with no reported overshoot. 70 (7000 ticks/s^2) targets ~0.31s for the same 170-tick "
                         "move -- this does NOT change grip_fast_to_pos (same target, just reached quicker), "
                         "so the main remaining risk is jerk/vibration, not a harder block impact. UNVERIFIED "
                         "beyond 48 -- watch for overshoot/vibration on the real arm before raising further")
    ap.add_argument("--grip-fast-timeout", type=float, default=2.0,
                    help="feature A: seconds allowed for the fast pre-close move before giving up and letting "
                         "the stall-crawl cover the remaining distance")
    # ---- feature B: pipeline block n+1's FEED+CONV against block n's CARRY/RELEASE/HOME
    ap.add_argument("--enable-b", type=int, default=0, choices=[0, 1],
                    help="feature B: overlap the next block's FEED+belt-travel with this block's "
                         "CARRY/RELEASE/HOME instead of doing them fully serially (TRANSPORT is ~46%% of "
                         "the baseline cycle, almost all of it the arm standing still). See "
                         "one_cycle_pipelined()'s docstring for the full sequence and the arm-clear-of-belt "
                         "gate. 0 = exact original serial FEED->TRANSPORT->GRIP->CARRY->RELEASE->HOME->CLEAR "
                         "order (default -- test this ONLY after A/D are confirmed stable, per the task's "
                         "own step-by-step rule). NOTE: transport_s reads ~0 in real_cycles_*.csv when this "
                         "is on -- there is no longer one single blocking TRANSPORT phase, see the docstring")
    # ---- feature D: lower gripper hold preload / torque limit during CARRY (was a fixed 150-tick squeeze)
    ap.add_argument("--enable-d", type=int, default=1, choices=[0, 1],
                    help="feature D: send a configurable hold preload/torque-limit with C,6 instead of the "
                         "firmware's fixed 150-tick, no-torque-cap default. 0 = exact original behaviour")
    ap.add_argument("--grip-hold-preload", type=int, default=150,
                    help="feature D: extra ticks the firmware squeezes past the measured contact point while "
                         "carrying (firmware default: fixed at 150, so 150 here reproduces it). ROUND 1 FINDING: "
                         "lowering this to 60 did NOT reduce J6's CARRY current (748-812 mA either way -- the "
                         "STS3215 position-PID looks saturated well before that point) and instead let the "
                         "block wobble enough that CARRY needed repeated resend+settle (1.28s baseline -> 3.70s "
                         "measured). Kept at the firmware default this round; --grip-hold-torque-limit is the "
                         "lever actually being tested for the current/heat reduction now")
    ap.add_argument("--grip-hold-torque-limit", type=int, default=180,
                    help="feature D: STS3215 torque limit (0-1000 = 0-100%%) applied only while holding the "
                         "block after G,CLOSED. 1000 = off/no cap. ROUND 1 ran with this off and lowered "
                         "--grip-hold-preload instead, which did not reduce current. ROUND 2's writeWord() call "
                         "was not retried and the Mega<->servo UART drops 15-35%% of replies, so the write was "
                         "silently failing -- current stayed ~750-810 mA even with this set to 300. ROUND 3 added "
                         "a retry + readback (reported on the G,CLOSED line and logged in real_cycles_*.csv's "
                         "grip_torque_limit_used, confirmed the write actually landed every cycle) and current "
                         "dropped to 286-377 mA in 10/12 cycles at 300 (30%%) -- confirming torque limit is the "
                         "right lever. 180 (18%%) pushes further now that the write is confirmed reliable. "
                         "UNVERIFIED below 300 -- watch j6_carry_pos_delta_deg in real_cycles_*.csv for slip "
                         "(block loosening/dropping), and raise this back up if it appears")
    # ---- grip verification + recovery after a failed cycle (200956 run: 3 "OK" cycles had gripped air, and after a belt
    # FAULT the next cycle gripped with no block at the IR)
    ap.add_argument("--enable-verify", type=int, default=1, choices=[0, 1],
                    help="1 = a grip that stops outside the block window is GRIP_MISS (retried), a GRIP must start with a block "
                         "at the IR, and a carry with a weak/slipping J6 is logged GRIP_SUSPECT instead of OK. 0 = old behaviour")
    ap.add_argument("--grip-contact-min-deg", type=float, default=178.0,
                    help="G,CLOSED position window that means 'a block is held' (clean grips measured 181.8-182.0 deg, air grips "
                         "165-172). Widen it if blocks vary; UNVERIFIED beyond the 6 clean grips of the 200956 run")
    ap.add_argument("--grip-contact-max-deg", type=float, default=186.0, help="upper end of the block window, deg")
    ap.add_argument("--grip-carry-min-ma", type=float, default=0.0,
                    help="J6 current peak while carrying below this = GRIP_SUSPECT. 0 = off (default): it flagged almost every clean "
                         "carry as soon as the hold torque limit went under ~150 (peaks were 6-13 mA at 50, 32 mA at 100, "
                         "110-150 mA at 180); the contact-angle window is the reliable grip check")
    ap.add_argument("--grip-slip-max-deg", type=float, default=2.0,
                    help="J6 moving more than this while carrying = GRIP_SUSPECT (clean carries moved <= 0.26 deg)")
    ap.add_argument("--enable-recover", type=int, default=1, choices=[0, 1],
                    help="pipelined mode only: after a failed cycle open the gripper, go Home then Standby and bring a block to the "
                         "IR (belt first, feeder only if the belt is empty) before the next cycle; a recovery that fails stops the run")
    ap.add_argument("--enable-c", type=int, default=0, choices=[0, 1],
                    help="feature C, belt queue (needs --enable-b): after one unqueued cycle has measured the full belt travel "
                         "time, a 2nd block is dropped on the moving belt --queue-split of the way through, so afterwards every "
                         "CONV only moves the next block about HALF the belt (shorter belt run + shorter wait for ARRIVED). "
                         "UNVERIFIED on the real belt: blocks left on the belt at the end of a run, and spacing after a FAULT "
                         "(not known any more -> no re-priming), have to be checked by eye. 0 = off")
    ap.add_argument("--pause-before-set", type=int, default=0, choices=[0, 1],
                    help="1 = pause before every set (also the first) until Resume / experiment.py resumes it; while paused, "
                         "POST /api/task can run a belt test or baseline. 0 = off (default, unchanged behaviour)")
    ap.add_argument("--queue-split", type=float, default=0.5,
                    help="where on the lead block's trip the 2nd block is dropped, as a fraction of the full travel time "
                         "(0.5 = the two end up half a belt apart)")
    ap.add_argument("--arrival-guard", type=int, default=1, choices=[0, 1],
                    help="1 = (pipeline) hold X,CONV back so the next block cannot reach the IR before the arm is parked at "
                         "Standby (+ --arrival-margin-s); estimated from the last 3 cycles. 0 = start CONV at the gate as before")
    ap.add_argument("--arrival-margin-s", type=float, default=0.5,
                    help="how long after the arm is parked the block may arrive at the earliest")
    ap.add_argument("--ir-confirm-s", type=float, default=0.6,
                    help="how long GRIP waits for the IR telemetry to show the block (it streams ~10 Hz, so the reading right "
                         "after ARRIVED can be stale) before it calls the IR empty (NO_BLOCK_AT_IR)")
    ap.add_argument("--recover-conv-s", type=float, default=7.0,
                    help="seconds the recovery runs the belt looking for a block already on it before it feeds a new one "
                         "(the full feed->IR run is ~5 s at 33 rpm)")
    for nm in ("standby", "grip", "drop", "home"):
        ap.add_argument(f"--dwell-{nm}", type=float, default=0.0, help=f"pause after arriving at / doing: {nm}, s")
    ap.add_argument("--pose-tol", type=int, default=POSE_TOL_TICKS)
    ap.add_argument("--grip-tol", type=int, default=GRIP_TOL_TICKS)
    ap.add_argument("--move-timeout", type=float, default=40.0, help="seconds allowed per arm move")
    ap.add_argument("--feed-timeout", type=float, default=5.0, help="seconds to wait for FEED_DONE")
    ap.add_argument("--arrive-timeout", type=float, default=20.0, help="seconds for a block to reach the IR")
    ap.add_argument("--clear-timeout", type=float, default=3.0, help="seconds for the block to leave the IR after the pick")
    ap.add_argument("--standby-timeout", type=float, default=45.0)
    ap.add_argument("--grip-timeout", type=float, default=12.0, help="seconds to wait for G,CLOSED / G,ERROR")
    ap.add_argument("--offset", type=int, default=0, help="extra encoder counts the belt travels after the IR triggers")
    ap.add_argument("--temp-max", type=float, default=60.0, help="belt motor over-temperature trip, C (0 = off)")
    ap.add_argument("--belt-wdt-ms", type=int, default=None,
                    help="belt watchdog timeout sent via X,WDT (0 = off, not recommended). Default: 500 "
                         "(firmware default, unchanged) when --enable-b=0; 1500 when --enable-b=1 -- feature "
                         "B measured FAULT_1 (watchdog) in 2/10 pipelined cycles at the firmware default even "
                         "though the PC kept sending X,HB on schedule (see one_cycle_pipelined()'s docstring "
                         "and apply_belt_settings() for why). TRADE-OFF: a higher value means the belt keeps "
                         "running longer before self-stopping if the PC genuinely hangs/crashes -- only raise "
                         "this as far as needed to clear false positives, and lower it again if --enable-b=0")
    ap.add_argument("--kp", type=float, default=4.5,
                    help="belt speed PID, PWM per rpm of error. 9 x the firmware default 0.5 / 1.5 / 0, which was tuned "
                         "with CPR 1320: at CPR 11880 the same belt speed reads 9x fewer rpm, so x9 gives the same PWM")
    ap.add_argument("--ki", type=float, default=13.5)
    ap.add_argument("--kd", type=float, default=0.0)
    ap.add_argument("--feeder-home", type=int, default=180)          # blade fully back (operator, 2026-10-27)
    ap.add_argument("--feeder-push", type=int, default=0)
    ap.add_argument("--feeder-push-ms", type=int, default=300)     # 180 -> 0 deg takes the MG90S ~0.3 s
    ap.add_argument("--feeder-return-ms", type=int, default=300)   # and the same back to 180
    ap.add_argument("--max-fails", type=int, default=3, help="stop after this many failed cycles in a row")
    ap.add_argument("--hold-tol", type=int, default=60,
                    help="while the arm should stand still, a joint further than this (ticks) from its pose is logged and pulled back; 0 = off")
    ap.add_argument("--settle-tol", type=int, default=100,
                    help="a joint that stops this close (ticks) outside the pose window for 1.5 s counts as arrived; 0 = off")
    ap.add_argument("--cpr", type=float, default=11880.0,
                    help="belt encoder counts per output revolution: 11 PPR x 4 (quadrature) x 1:270 (JGB37-520, 37 rpm). "
                         "Sent to the Mega as X,CPR at Start; it sets what every belt rpm means")
    ap.add_argument("--web-port", type=int, default=8781, help="0 = no web page")
    ap.add_argument("--log-dir", default="riff_logs")
    ap.add_argument("--auto-start", action="store_true",
                    help="start the run immediately (default: open the web page and wait for the Start button)")
    ap.add_argument("--yes", action="store_true", help="with --auto-start: skip the 'arm area is clear' question")
    return ap


def main(argv=None):
    ap = build_parser()
    args = ap.parse_args(argv)
    grip_cal = load_grip_cal(args.grip_cal)
    if grip_cal:
        ap.set_defaults(**grip_cal)
        args = ap.parse_args(argv)

    # ---- sanity checks before anything moves
    if args.grip_contact_min_deg >= args.grip_contact_max_deg:
        raise SystemExit("--grip-contact-min-deg must be below --grip-contact-max-deg")
    if not (1 <= args.sets <= 1000 and 1 <= args.cycles_per_set <= 1000):
        raise SystemExit("sets and cycles-per-set must be 1..1000")
    if not (0.2 <= args.arm_speed <= 8.8 and 0.5 <= args.rpm <= 37):
        raise SystemExit("check --arm-speed 0.2..8.8, --rpm 0.5..37")
    if args.poses:
        with open(args.poses, "r", encoding="utf-8") as f:
            poses = json.load(f)
    else:
        poses = json.loads(json.dumps(DEFAULT_POSES))
    for need in ("up", "right", "left", "down"):
        if need not in poses or any(str(i) not in poses[need] for i in range(1, 7)):
            raise SystemExit(f"the poses must contain pose '{need}' with joints 1..6")
    args.pose_cfg = load_pose_config(args.pose_config)
    if args.pose_cfg:
        poses["rest"] = args.pose_cfg["rest"]
    elif args.resting:
        raise SystemExit("--resting needs the wake sequence from --pose-config (config/poses.json)")
    if args.resting and args.awake:
        raise SystemExit("--resting and --awake contradict each other")
    if args.rest_file is None:
        args.rest_file = "" if args.port == "SIMULATED" else REST_FILE   # the simulator never touches the real memory
    if initial_rest_state(args) != "awake" and not args.pose_cfg:
        raise SystemExit(f"{args.rest_file} says the arm is resting, but there is no wake sequence (--pose-config)")
    if initial_rest_state(args) != "awake":
        print(f"ARM RESTING ({initial_rest_state(args)}) according to {args.rest_file or '--resting'}: Start moves "
              "nothing; send the wake task, then Resume. Use --awake if the arm is not on the cradle.")
    if not args.no_mqtt and mqtt is None:
        raise SystemExit("paho-mqtt is not installed:  pip install paho-mqtt   (or run with --no-mqtt)")
    if not (1.0 <= args.mqtt_hz <= 20.0):
        raise SystemExit("--mqtt-hz must be 1..20")
    if args.open_pos is None:
        # feature A: a lower default open position (less travel to close) when enabled; the exact
        # original default (pose 'up' joint 6) when disabled, so --enable-a 0 is a true revert.
        args.open_pos = args.grip_open_pos_a if args.enable_a else int(poses["up"]["6"])
    args.wdt_auto = args.belt_wdt_ms is None               # decided again at Start: B is usually switched on from the web page, after this line
    if args.belt_wdt_ms is None:
        # feature B: more slack for the belt watchdog only when the belt now runs concurrently with the
        # arm's busiest moves; --enable-b 0 keeps the exact firmware default (500), unchanged.
        args.belt_wdt_ms = 1500 if args.enable_b else 500
    if args.web_port == 0 and not args.auto_start:
        raise SystemExit("with --web-port 0 there is no Start button: add --auto-start")
    if args.auto_start and not args.yes:
        print(f"This will move the arm and run the conveyor with REAL blocks: {args.sets} sets x {args.cycles_per_set} cycles "
              f"= {args.sets * args.cycles_per_set} cycles (~{args.sets * args.cycles_per_set * 20 // 60} min).")
        if input("Is the arm area clear and the E-stop within reach?  type YES: ").strip() != "YES":
            raise SystemExit("not started")

    # ---- connect
    if args.port is None:
        args.port = find_serial_port()
    print(f"Mega port: {args.port}")
    try:
        link = Link(args.port)
    except serial.SerialException as e:
        raise SystemExit(f"cannot open {args.port}: {e}\nClose every other program that uses it "
                         "(Arduino Serial Monitor, the other dashboard) and try again.")
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    print(f"boot banner seen: {link.boot_seen}")
    try:
        link.wait_ready()
    except TimeoutError as e:
        link.close()
        raise SystemExit(str(e))

    mq = None if args.no_mqtt else Mqtt(args.mqtt_host, args.mqtt_port)
    study = Study(link, args, poses, stamp, mq)
    publisher = Publisher(study, mq, args.mqtt_hz) if mq else None
    if publisher:
        publisher.start()
    link.txlog = open(os.path.join(args.log_dir, f"autoen_tx_{stamp}.log"), "w", encoding="utf-8", buffering=1)
    srv = serve(study, args.web_port, args.web_host) if args.web_port else None
    if srv:
        print(f"live page: http://{'127.0.0.1' if args.web_host == '0.0.0.0' else args.web_host}:{args.web_port}  - set the parameters there and press Start")
        try:
            webbrowser.open(f"http://127.0.0.1:{args.web_port}")
        except Exception:                                   # noqa: BLE001 - no browser is not an error
            pass
    if args.auto_start:
        study.start_evt.set()
    print(f"files: {study.p_raw}\n       {study.p_sets}\n       {study.p_cyc}\n       {study.p_thr}")
    try:
        study.run()
    except KeyboardInterrupt:
        study.stop_evt.set()
        print("Ctrl+C: stopping (belt coasts, arm holds)")
    finally:
        if srv:
            srv.shutdown()
        if publisher:
            publisher.stop_evt.set()
        link.close()
        if mq:
            mq.close()
    if link.txlog:
        link.note(f"## end, unparsable RX lines: {link.bad_rx}")
        link.txlog.close()
    print(f"{study.status}: {study.message}  (unparsable RX lines: {link.bad_rx})")
    return 0 if study.status == "finished" else 1


if __name__ == "__main__":
    raise SystemExit(main())
