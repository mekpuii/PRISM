# test_feed_check.py - did the feeder servo really push? (optimize._watch_feed, from the 2026-11-10 logs: the Mega
# answers FEED_DONE by time only; a real push dips the 12 V rail 33-125 mV, a dead one <= 6 mV.)
# No robot, no broker, no autoen.
# Run (orch-env, from orchestrator/):  python3 test/test_feed_check.py     Expected last line: "all feed check tests passed"
import os
import sys
import tempfile
from dataclasses import replace

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import optimize as O                                               # noqa: E402
from observe import ArmStatus                                      # noqa: E402
from test_opt import cyc, pred, view                               # noqa: E402
from test_smart import settings, tele                              # noqa: E402

V0 = 12.171


class Cell:
    def __init__(self, opt):
        self.opt, self.t, self.n = opt, 0.0, 1

    def tick(self, phase, volts, cycles=(), paused=False):
        self.t += 0.1                                               # belt telemetry: 10 Hz
        s = tele(self.t)
        s.belt.voltage_v, s.belt.live_t = volts, self.t
        s.arm = ArmStatus(phase=phase, live_t=self.t)
        v = replace(view(self.t, phase=phase, cycles=cycles, config=settings(self.opt), paused=paused,
                         status="paused" if paused else "running"), cycle_total=self.n)
        return self.opt.step(s, pred(self.t), v)

    def feed(self, dip_mv):
        """IDLE 1 s, FEED 0.6 s with this dip on the rail, then the first TRANSPORT tick. Returns that plan."""
        self.n += 1
        for _ in range(10):
            self.tick("IDLE", V0)
        for _ in range(6):
            self.tick("FEED", V0 - dip_mv / 1000.0)
        return self.tick("TRANSPORT", V0)

    def end(self, result):
        for _ in range(3):
            self.tick("TRANSPORT", V0)
        return self.tick("IDLE", V0, cycles=[cyc(self.n, result)], paused=self.opt.mode == "ALERT")


def armed():
    opt = O.Optimize()
    opt.feed_moved = O.FEED_ARM_PUSHES
    c = Cell(opt)
    c.tick("IDLE", V0)
    assert opt.mode == "RUN"
    return opt, c


def main():
    # 1. A real push (80 mV dip): nothing to do. A dead push (0 mV): feed again at once, twice; the third -> ALERT.
    opt, c = armed()
    p = c.feed(80)
    assert p.action is None and opt.feed_stats == {"pushes": 1, "dead": 0, "last_dip_mV": 80}, (p.action, opt.feed_stats)
    c.end("OK")
    p = c.feed(0)
    assert p.action == "refeed" and "did not move" in opt.reason and "(1/2)" in opt.reason, (p.action, opt.reason)
    c.end(O.NO_BLOCK)
    assert opt.mode == "RUN" and opt._refeeds_left == O.REFEEDS, "a dead push used up the camera's refeed"
    p = c.feed(2)
    assert p.action == "refeed" and "(2/2)" in opt.reason, (p.action, opt.reason)
    c.end(O.NO_BLOCK)
    p = c.feed(1)
    assert p.action == "abort" and opt.mode == "ALERT" and "check its plug" in opt.reason, (p.action, opt.reason)
    c.end(O.NO_BLOCK)
    assert opt.mode == "ALERT" and "feeder servo" in opt.reason, (opt.mode, opt.reason)
    print(f"dead push:  no dip on the 12 V rail -> fed again at once (2 x), then: {opt.reason[:62]}...   OK")

    # 2. A dead push, then the servo works again: the count starts over (it is intermittent).
    opt, c = armed()
    assert c.feed(0).action == "refeed"
    c.end(O.NO_BLOCK)
    assert c.feed(95).action is None and opt._dead_row == 0
    c.end("OK")
    assert c.feed(0).action == "refeed" and "(1/2)" in opt.reason
    print("recovers:   dead, then a real push -> the cube is picked, the count starts over   OK")

    # 3. Not armed (the dip was never seen on this machine, e.g. a simulator): a missing dip means nothing.
    opt = O.Optimize()
    c = Cell(opt)
    c.tick("IDLE", V0)
    assert c.feed(0).action is None and opt.feed_stats["dead"] == 0
    for _ in range(O.FEED_ARM_PUSHES):
        c.end("OK")
        assert c.feed(70).action is None
    c.end("OK")
    assert c.feed(0).action == "refeed", "5 real pushes seen: it must be armed now"
    print(f"arming:     unarmed -> ignored; after {O.FEED_ARM_PUSHES} real pushes a missing dip counts   OK")

    # 4. The first cycle of a run (arm still driving home) and an unclear dip (20 mV): no verdict.
    opt, c = armed()
    c.n = 0
    assert c.feed(0).action is None, "judged the first cycle of a run"
    c.end("OK")
    assert c.feed(20).action is None and opt.feed_stats["dead"] == 0
    print("careful:    first cycle of a run and an unclear 20 mV dip -> no verdict   OK")

    # 5. Kept across restarts.
    path = os.path.join(tempfile.mkdtemp(prefix="prism_feedcheck_"), "learned.json")
    opt = O.Optimize(learned_path=path)
    c = Cell(opt)
    c.tick("IDLE", V0)
    for _ in range(6):
        c.feed(60)
        c.end("OK")
    assert O.Optimize(learned_path=path).feed_moved >= O.FEED_ARM_PUSHES
    print("memory:     the pushes seen are kept in learned_state.json: armed from the first run after   OK")

    print("\nall feed check tests passed")


if __name__ == "__main__":
    main()
